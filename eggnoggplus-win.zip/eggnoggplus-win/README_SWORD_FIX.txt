This archive contains a source-level fix for the mods-menu sword selector regression.

What changed
- Removed the old approach that moved the live cursor structs offscreen during blur capture.
- Replaced it with a call to Eggnogg's native main_cursors_disable(1/0) around the blur background capture pass.

Why
- Moving the live cursor structs before p_menu_common_render() caused the engine to prepare/draw the swords offscreen.
- Disabling cursors for the blur-capture pass avoids baking them into the blur while preserving their real runtime state for the final draw.

Important
- I could not rebuild SDL2.dll inside the container because the Windows MinGW toolchain/headers were not available here.
- Build this on your Windows MinGW setup with compile.sh.

Expected build command
- In your MINGW32 shell, from this folder:
    ./compile.sh

Key file touched
- hooks.c
