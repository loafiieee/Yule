#include <windows.h>
#include <excpt.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include <GL/gl.h>
#ifdef __has_include
#  if __has_include(<GL/glext.h>)
#    include <GL/glext.h>
#  endif
#endif

/* Fallback defines for texture-combine constants (in case glext.h isn't available). */
#ifndef GL_COMBINE
#define GL_COMBINE 0x8570
#endif
#ifndef GL_COMBINE_RGB
#define GL_COMBINE_RGB 0x8571
#endif
#ifndef GL_SOURCE0_RGB
#define GL_SOURCE0_RGB 0x8580
#endif
#ifndef GL_SOURCE1_RGB
#define GL_SOURCE1_RGB 0x8581
#endif
#ifndef GL_OPERAND0_RGB
#define GL_OPERAND0_RGB 0x8590
#endif
#ifndef GL_OPERAND1_RGB
#define GL_OPERAND1_RGB 0x8591
#endif
#ifndef GL_COMBINE_ALPHA
#define GL_COMBINE_ALPHA 0x8572
#endif
#ifndef GL_SOURCE0_ALPHA
#define GL_SOURCE0_ALPHA 0x8588
#endif
#ifndef GL_OPERAND0_ALPHA
#define GL_OPERAND0_ALPHA 0x8598
#endif
#ifndef GL_PREVIOUS
#define GL_PREVIOUS 0x8578
#endif

#include "hooks.h"
#include "lua_manager.h"
#include "font_ext.h"
#include "texture_ext.h"
#include "custom_maps.h"
#include "log.h"


#define ADDR_STATE_CURRENT            0x405DB0u
#define ADDR_STATE_LAST               0x405DB8u
#define ADDR_STATE_SWITCH             0x405DC0u
#define ADDR_MAIN_UPDATE_WITH_BUTTONS 0x4340E0u
#define ADDR_MAIN_DRAW              0x4331A0u
#define ADDR_MENU_COMMON_RENDER       0x4334E0u
#define ADDR_MAIN_BUTTONS_START       0x432FD0u
#define ADDR_MAIN_CURSORS_RESET       0x431200u
#define ADDR_MAIN_CURSOR_SPIN        0x4311E0u
#define ADDR_MAIN_CURSOR_DATA        0x549140u
#define ADDR_MAIN_SPRITE_BATCHES_DRAW 0x431890u
#define ADDR_SPRITE_BATCH_PLOT        0x405890u
#define ADDR_SPRITE_BATCH_DRAW        0x405A90u
#define ADDR_MENU_BUTTON_LINK         0x433950u
#define ADDR_BUTTON_SET_LAYOUT        0x415F80u
#define ADDR_BTN_PLAYER_FILTER        0x4325C0u
#define ADDR_PLOT_TEXT                0x4304E0u
#define ADDR_PLOT_TEXT_SET_SHADOW     0x430390u
#define ADDR_TURTLE_SET_ANGLE         0x409000u
#define ADDR_TURTLE_SET_POS_UNSCALED  0x409040u
#define ADDR_TURTLE_SET_SCALE         0x409080u
#define ADDR_TURTLE_SET_RGB           0x4091E0u
#define ADDR_TURTLE_SET_RGBA          0x4090C0u
#define ADDR_TURTLE_RESET             0x4092D0u
#define ADDR_MAD_W                    0x404300u
#define ADDR_MAD_H                    0x404320u
#define ADDR_OPTIONS_STATE            0x448398u
#define ADDR_OPTIONS_STATE_PAUSED     0x448388u
#define ADDR_MAIN_STATE               0x448350u
#define ADDR_MAIN_STATE_INITIAL       0x448340u
#define ADDR_OPTIONS_ENTER            0x4381F0u
#define ADDR_OPTIONS_ENTER_PAUSED     0x438200u
#define ADDR_MAIN_PLAYER_POLL_CMDS    0x433F90u
#define ADDR_MAPGEN_INIT              0x437D30u

// Asset load hook used for moddable font glyph overlays.
#define ADDR_RGBA_LOAD                0x4022A0u

#define MAX_MENU_ROWS     2048
#define CAPTURE_BUF_SIZE   256
#define BASE_UI_W        1280.0f
#define BASE_UI_H         720.0f
#define MODS_CURSOR_ROW_Y_FACTOR   0.50f
#define MODS_CURSOR_ROW_Y_NUDGE    0.0f
#define MODS_CURSOR_OUTER_PAD_X   22.0f

#define MODS_BTN_GRID_X      1.0f
#define MODS_BTN_GRID_Y      0.0f

#define SDLK_BACKSPACE      8
#define SDLK_TAB            9
#define SDLK_RETURN        13
#define SDLK_ESCAPE        27
#define SDLK_SPACE         32
#define SDLK_DELETE       127
#define SDLK_HOME 1073741898
#define SDLK_END  1073741901
#define SDLK_PAGEUP 1073741899
#define SDLK_PAGEDOWN 1073741902
#define SDLK_RIGHT 1073741903
#define SDLK_LEFT  1073741904
#define SDLK_DOWN  1073741905
#define SDLK_UP    1073741906
#define SDLK_KP_ENTER 1073741912

#define KMOD_SHIFT 0x0003
#define KMOD_CTRL  0x00C0

#define CONSOLE_INPUT_BUF      512
#define CONSOLE_LINE_TEXT      384
#define CONSOLE_MAX_LINES      256
#define CONSOLE_HISTORY_MAX     64
#define CONSOLE_BG_DOWNSAMPLE    4

typedef struct GameState {
    void (__cdecl *enter)(void);
    void (__cdecl *update)(void);
    void (__cdecl *render)(void);
    void (__cdecl *leave)(void);
} GameState;

typedef enum RowKind {
    ROW_NONE = 0,
    ROW_MOD_HEADER,
    ROW_DIVIDER,
    ROW_CONFIG,
    ROW_BACK,
    ROW_INFO,
} RowKind;

typedef struct MenuRow {
    RowKind kind;
    int selectable;
    int mod_index;
    int cfg_index;
    char left[128];
    char right[192];
} MenuRow;

typedef struct RowKey {
    RowKind kind;
    int mod_index;
    int cfg_index;
} RowKey;

typedef struct ConsoleLine {
    char text[CONSOLE_LINE_TEXT];
    float r;
    float g;
    float b;
} ConsoleLine;

typedef struct Detour {
    void* target;
    uint8_t original[16];
    size_t length;
    void* trampoline;
} Detour;

typedef void* (__cdecl *fn_state_current_t)(void);
typedef void* (__cdecl *fn_state_switch_t)(void*);
typedef int   (__cdecl *fn_main_update_with_buttons_t)(int);
typedef void  (__cdecl *fn_void_void_t)(void);
typedef void  (__cdecl *fn_main_cursors_reset_t)(float, float);
typedef void  (__cdecl *fn_main_cursor_spin_t)(int);
typedef void  (__cdecl *fn_main_sprite_batches_draw_t)(void);
typedef void  (__cdecl *fn_sprite_batch_plot_t)(int sprite, int flip, int layer);
typedef void  (__cdecl *fn_sprite_batch_draw_t)(int atlas);
typedef void* (__cdecl *fn_menu_button_link_t)(float, float, const char*, void*);
typedef void  (__cdecl *fn_button_set_layout_t)(float, float);
typedef int   (__cdecl *fn_btn_player_filter_t)(void* btn, int event_code);
typedef void  (__cdecl *fn_plot_text_t)(const char*, int);
typedef void  (__cdecl *fn_plot_text_set_shadow_t)(float, float, float, float);
typedef void  (__cdecl *fn_turtle_set_angle_t)(double);
typedef void  (__cdecl *fn_turtle_set_pos_unscaled_t)(double, double);
typedef void  (__cdecl *fn_turtle_set_scale_t)(double, double);
typedef void  (__cdecl *fn_turtle_set_rgb_t)(float, float, float);
typedef void  (__cdecl *fn_turtle_set_rgba_t)(float, float, float, float);
typedef void  (__cdecl *fn_turtle_reset_t)(void);
typedef float (__cdecl *fn_mad_dim_t)(void);
typedef RgbaImage* (__cdecl *fn_rgba_load_t)(const char*);
typedef uint32_t (__cdecl *fn_main_player_poll_cmds_t)(uint32_t, uint32_t);

static fn_state_current_t            p_state_current = (fn_state_current_t)(uintptr_t)ADDR_STATE_CURRENT;
static fn_state_current_t            p_state_last = (fn_state_current_t)(uintptr_t)ADDR_STATE_LAST;
static fn_state_switch_t             p_state_switch = (fn_state_switch_t)(uintptr_t)ADDR_STATE_SWITCH;
static fn_main_update_with_buttons_t p_main_update_with_buttons = (fn_main_update_with_buttons_t)(uintptr_t)ADDR_MAIN_UPDATE_WITH_BUTTONS;
static fn_void_void_t                p_main_draw = (fn_void_void_t)(uintptr_t)ADDR_MAIN_DRAW;
static fn_void_void_t                p_menu_common_render = (fn_void_void_t)(uintptr_t)ADDR_MENU_COMMON_RENDER;
static fn_void_void_t                p_main_buttons_start = (fn_void_void_t)(uintptr_t)ADDR_MAIN_BUTTONS_START;
static fn_main_cursors_reset_t       p_main_cursors_reset = (fn_main_cursors_reset_t)(uintptr_t)ADDR_MAIN_CURSORS_RESET;
static fn_main_cursor_spin_t        p_main_cursor_spin = (fn_main_cursor_spin_t)(uintptr_t)ADDR_MAIN_CURSOR_SPIN;
static fn_main_sprite_batches_draw_t p_main_sprite_batches_draw = (fn_main_sprite_batches_draw_t)(uintptr_t)ADDR_MAIN_SPRITE_BATCHES_DRAW;
static fn_menu_button_link_t         p_menu_button_link = (fn_menu_button_link_t)(uintptr_t)ADDR_MENU_BUTTON_LINK;
static fn_button_set_layout_t        p_button_set_layout = (fn_button_set_layout_t)(uintptr_t)ADDR_BUTTON_SET_LAYOUT;
static fn_btn_player_filter_t        p_btn_player_filter = (fn_btn_player_filter_t)(uintptr_t)ADDR_BTN_PLAYER_FILTER;
static fn_plot_text_t                p_plot_text = (fn_plot_text_t)(uintptr_t)ADDR_PLOT_TEXT;
static fn_plot_text_set_shadow_t     p_plot_text_set_shadow = (fn_plot_text_set_shadow_t)(uintptr_t)ADDR_PLOT_TEXT_SET_SHADOW;
static fn_turtle_set_angle_t         p_turtle_set_angle = (fn_turtle_set_angle_t)(uintptr_t)ADDR_TURTLE_SET_ANGLE;
static fn_turtle_set_pos_unscaled_t  p_turtle_set_pos_unscaled = (fn_turtle_set_pos_unscaled_t)(uintptr_t)ADDR_TURTLE_SET_POS_UNSCALED;
static fn_turtle_set_scale_t         p_turtle_set_scale = (fn_turtle_set_scale_t)(uintptr_t)ADDR_TURTLE_SET_SCALE;
static fn_turtle_set_rgb_t           p_turtle_set_rgb = (fn_turtle_set_rgb_t)(uintptr_t)ADDR_TURTLE_SET_RGB;
static fn_turtle_set_rgba_t          p_turtle_set_rgba = (fn_turtle_set_rgba_t)(uintptr_t)ADDR_TURTLE_SET_RGBA;
static fn_turtle_reset_t             p_turtle_reset = (fn_turtle_reset_t)(uintptr_t)ADDR_TURTLE_RESET;
static fn_mad_dim_t                  p_mad_w = (fn_mad_dim_t)(uintptr_t)ADDR_MAD_W;
static fn_mad_dim_t                  p_mad_h = (fn_mad_dim_t)(uintptr_t)ADDR_MAD_H;
static fn_void_void_t                p_options_enter = (fn_void_void_t)(uintptr_t)ADDR_OPTIONS_ENTER;
static fn_void_void_t                p_options_enter_paused = (fn_void_void_t)(uintptr_t)ADDR_OPTIONS_ENTER_PAUSED;
static fn_void_void_t                p_mapgen_init = (fn_void_void_t)(uintptr_t)ADDR_MAPGEN_INIT;
static fn_void_void_t                p_options_enter_trampoline = NULL;
static fn_void_void_t                p_options_enter_paused_trampoline = NULL;
static fn_void_void_t                p_mapgen_init_trampoline = NULL;
static fn_state_switch_t             p_state_switch_trampoline = NULL;
static fn_main_player_poll_cmds_t    p_main_player_poll_cmds = (fn_main_player_poll_cmds_t)(uintptr_t)ADDR_MAIN_PLAYER_POLL_CMDS;
static fn_main_player_poll_cmds_t    p_main_player_poll_cmds_trampoline = NULL;

static fn_rgba_load_t                p_rgba_load = (fn_rgba_load_t)(uintptr_t)ADDR_RGBA_LOAD;
static fn_rgba_load_t                p_rgba_load_trampoline = NULL;

static Detour g_options_enter_detour;
static Detour g_options_enter_paused_detour;
static Detour g_state_switch_detour;
static Detour g_main_player_poll_cmds_detour;
static Detour g_rgba_load_detour;
static Detour g_mapgen_init_detour;

static MenuRow g_rows[MAX_MENU_ROWS];
static int g_row_count = 0;
static int g_selected_row = -1;
static int g_scroll_row = 0;

static int g_capture_active = 0;
static int g_capture_mod = -1;
static int g_capture_cfg = -1;
static char g_capture_buf[CAPTURE_BUF_SIZE];
static float g_ui_scale = 1.0f;

// Minimal developer console state.
static void* g_console_return_state = (void*)(uintptr_t)ADDR_MAIN_STATE;
static void* g_console_pending_return_state = (void*)(uintptr_t)ADDR_MAIN_STATE;
static int g_console_open_pending = 0;
static int g_console_open_ready = 0;
static int g_console_suppress_next_textinput = 0;
static int g_console_scroll = 0;
static char g_console_input[CONSOLE_INPUT_BUF];
static int g_console_cursor = 0;
static char g_console_edit_stash[CONSOLE_INPUT_BUF];
static int g_console_has_edit_stash = 0;
static int g_console_history_pos = -1;
static char g_console_history[CONSOLE_HISTORY_MAX][CONSOLE_INPUT_BUF];
static int g_console_history_count = 0;
static ConsoleLine g_console_lines[CONSOLE_MAX_LINES];
static int g_console_line_head = 0;
static int g_console_line_count = 0;
static GLuint g_console_bg_tex = 0;
static int g_console_bg_w = 0;
static int g_console_bg_h = 0;
static int g_console_bg_ready = 0;

// Command-bit overrides applied in the main_player_poll_cmds detour.
static volatile uint32_t g_input_override_mask[2] = { 0, 0 };
static volatile int g_input_override_frames[2] = { 0, 0 };
static volatile int g_input_override_replace[2] = { 0, 0 };

// Forward decls for UI layout + state checks used by cursor hijack.
typedef struct ModsLayout {
    float w;
    float h;
    float ui;
    float text_scale;
    float center_x;
    float content_w;
    float left;
    float right;
    float label_x;
    float value_x;
    float list_top;
    float list_bottom;
    float row_h;
} ModsLayout;

static int is_mods_state_active(void);
static int is_console_state_active(void);
static void mods_calc_layout(ModsLayout* L);

typedef struct MainCursor {
    float x;
    float y;
    float tx;
    float ty;
    float v;
    float spin;
} MainCursor;

static volatile MainCursor* g_main_cursors = (volatile MainCursor*)(uintptr_t)ADDR_MAIN_CURSOR_DATA;
static float g_cursor_x[2] = { 0.0f, 0.0f };
static float g_cursor_y[2] = { 0.0f, 0.0f };
static float g_cursor_tx[2] = { 0.0f, 0.0f };
static float g_cursor_ty[2] = { 0.0f, 0.0f };
static int g_cursor_initialized = 0;
static int g_cursor_bump = 0;

static void write_main_cursor_pos(int idx, float x, float y) {
    if (idx < 0 || idx >= 2) return;
    if (!g_main_cursors) return;

    g_main_cursors[idx].x = x;
    g_main_cursors[idx].y = y;
    g_main_cursors[idx].tx = x;
    g_main_cursors[idx].ty = y;
}

static void mods_cursor_on_selection_changed(void) {
    g_cursor_bump = 7;
}

static void mods_cursor_tick(void) {
    if (!is_mods_state_active()) return;
    if (g_selected_row < 0 || g_selected_row >= g_row_count) return;

    ModsLayout L;
    mods_calc_layout(&L);
    g_ui_scale = L.text_scale;

    // Determine target position from selected row.
    float row_y = L.list_top + ((float)(g_selected_row - g_scroll_row) * L.row_h)
                + (L.row_h * MODS_CURSOR_ROW_Y_FACTOR)
                + (MODS_CURSOR_ROW_Y_NUDGE * L.ui);

    // Place swords just outside the content region so they don't clip into text.
    float left_x  = L.left  - (MODS_CURSOR_OUTER_PAD_X * L.ui);
    float right_x = L.right + (MODS_CURSOR_OUTER_PAD_X * L.ui);
    // Keep within window bounds.
    {
        float w = L.w;
        float margin = 18.0f * L.ui;
        if (left_x < margin) left_x = margin;
        if (right_x > w - margin) right_x = w - margin;
    }

    if (g_rows[g_selected_row].kind == ROW_BACK) {
        left_x  = L.center_x - (84.0f * L.ui);
        right_x = L.center_x + (84.0f * L.ui);
    }

    g_cursor_tx[0] = left_x;
    g_cursor_ty[0] = row_y;
    g_cursor_tx[1] = right_x;
    g_cursor_ty[1] = row_y;

    if (!g_cursor_initialized) {
        g_cursor_x[0] = g_cursor_tx[0];
        g_cursor_y[0] = g_cursor_ty[0];
        g_cursor_x[1] = g_cursor_tx[1];
        g_cursor_y[1] = g_cursor_ty[1];
        g_cursor_initialized = 1;
    } else {
        // Smooth follow.
        float k = 0.35f;
        g_cursor_x[0] += (g_cursor_tx[0] - g_cursor_x[0]) * k;
        g_cursor_y[0] += (g_cursor_ty[0] - g_cursor_y[0]) * k;
        g_cursor_x[1] += (g_cursor_tx[1] - g_cursor_x[1]) * k;
        g_cursor_y[1] += (g_cursor_ty[1] - g_cursor_y[1]) * k;
    }
    // Keep engine cursor state initialized, then override exact sword positions
    // for this non-button list UI.
    if (g_cursor_bump > 0) g_cursor_bump--;

    if (p_main_cursors_reset) {
        float cx = (g_cursor_x[0] + g_cursor_x[1]) * 0.5f;
        float cy = (g_cursor_y[0] + g_cursor_y[1]) * 0.5f;
        p_main_cursors_reset(cx, cy);
    }

    write_main_cursor_pos(0, g_cursor_x[0], g_cursor_y[0]);
    write_main_cursor_pos(1, g_cursor_x[1], g_cursor_y[1]);
}

static void* g_mods_return_state = (void*)(uintptr_t)ADDR_OPTIONS_STATE;
static void __cdecl console_enter(void);
static void __cdecl console_update(void);
static void __cdecl console_render(void);
static void __cdecl console_leave(void);

static void __cdecl mods_enter(void);
static void __cdecl mods_update(void);
static void __cdecl mods_render(void);
static void __cdecl mods_leave(void);
static void __cdecl mods_entry_enter(void);
static void __cdecl mods_entry_update(void);
static void __cdecl mods_entry_render(void);
static void __cdecl mods_entry_leave(void);

static GameState g_mods_state = {
    mods_enter,
    mods_update,
    mods_render,
    mods_leave,
};

static GameState g_console_state = {
    console_enter,
    console_update,
    console_render,
    console_leave,
};

static GameState g_mods_entry_state = {
    mods_entry_enter,
    mods_entry_update,
    mods_entry_render,
    mods_entry_leave,
};

static int clampi(int v, int lo, int hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static float clampf(float v, float lo, float hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static float calc_ui_scale(void) {
    float w = p_mad_w ? p_mad_w() : BASE_UI_W;
    float h = p_mad_h ? p_mad_h() : BASE_UI_H;
    float sx = w / BASE_UI_W;
    float sy = h / BASE_UI_H;
    float s = (sx < sy) ? sx : sy;
    // Our custom mods menu should remain readable across a much wider range
    // of window sizes than the base game UI.
    return clampf(s, 0.75f, 1.60f);
}

static void safe_copy(char* dst, size_t dst_sz, const char* src) {
    if (!dst || dst_sz == 0) return;
    if (!src) src = "";
    strncpy(dst, src, dst_sz - 1);
    dst[dst_sz - 1] = '\0';
}

static int str_bool_true(const char* s) {
    if (!s) return 0;
    if (_stricmp(s, "1") == 0) return 1;
    if (_stricmp(s, "true") == 0) return 1;
    if (_stricmp(s, "yes") == 0) return 1;
    if (_stricmp(s, "on") == 0) return 1;
    return 0;
}

static int str_bool_false(const char* s) {
    if (!s) return 0;
    if (_stricmp(s, "0") == 0) return 1;
    if (_stricmp(s, "false") == 0) return 1;
    if (_stricmp(s, "no") == 0) return 1;
    if (_stricmp(s, "off") == 0) return 1;
    return 0;
}

static int is_mods_state_active(void) {
    return p_state_current && (p_state_current() == (void*)&g_mods_state);
}

static int is_console_state_active(void) {
    return p_state_current && (p_state_current() == (void*)&g_console_state);
}

static const char* state_name_from_ptr(void* st) {
    if (!st) return "none";
    if (st == (void*)&g_console_state) return "console";
    if (st == (void*)&g_mods_state) return "mods";
    if (st == (void*)&g_mods_entry_state) return "mods_entry";
    if (st == (void*)(uintptr_t)ADDR_MAIN_STATE) return "main";
    if (st == (void*)(uintptr_t)ADDR_MAIN_STATE_INITIAL) return "main_initial";
    if (st == (void*)(uintptr_t)ADDR_OPTIONS_STATE) return "options";
    if (st == (void*)(uintptr_t)ADDR_OPTIONS_STATE_PAUSED) return "options_paused";
    return "unknown";
}

static float approx_text_width(const char* text, float scale) {
    if (!text) return 0.0f;
    // font8x8 atlas is 145x145 (16x16 cells with 1px gutters):
    // effective advance is 9px per glyph at scale=1.
    return (float)strlen(text) * 9.0f * scale;
}

static void mods_restore_render_state(void) {
    // Reset full turtle state when possible. The cursor/shadow pass depends on
    // more than angle/scale/color, and partial restores can make shadows look
    // like extra mini swords.
    if (p_turtle_reset) {
        p_turtle_reset();
        return;
    }

    // Fallback for builds where turtle_reset is unavailable.
    p_turtle_set_angle(0.0);
    p_turtle_set_scale(1.0, 1.0);
    if (p_turtle_set_rgba) p_turtle_set_rgba(1.0f, 1.0f, 1.0f, 1.0f);
    else p_turtle_set_rgb(1.0f, 1.0f, 1.0f);
}

static void draw_text_scaled_mode(float x, float y, float scale, float r, float g, float b, const char* text, int mode) {
    if (!text || !p_plot_text) return;
    p_turtle_set_angle(0.0);
    p_turtle_set_scale((double)scale, (double)scale);
    p_turtle_set_rgb(r, g, b);
    p_turtle_set_pos_unscaled((double)x, (double)y);
    p_plot_text(text, mode);
}

static void draw_text_scaled(float x, float y, float scale, float r, float g, float b, const char* text) {
    // Left-aligned (base engine: plot_text align=0).
    draw_text_scaled_mode(x, y, scale, r, g, b, text, 0);
}

static void draw_text(float x, float y, float r, float g, float b, const char* text) {
    draw_text_scaled(x, y, g_ui_scale, r, g, b, text);
}

static void draw_text_centered_scaled(float cx, float y, float scale, float r, float g, float b, const char* text) {
    // plot_text mode=1 is already centered around turtle x in the base UI.
    draw_text_scaled_mode(cx, y, scale, r, g, b, text, 1);
}

static void draw_text_right_scaled(float right_x, float y, float scale, float r, float g, float b, const char* text) {
    // Right-aligned (base engine: plot_text align=2).
    draw_text_scaled_mode(right_x, y, scale, r, g, b, text, 2);
}

static void draw_text_centered(float cx, float y, float r, float g, float b, const char* text) {
    draw_text_centered_scaled(cx, y, g_ui_scale, r, g, b, text);
}

static void draw_text_right(float right_x, float y, float r, float g, float b, const char* text) {
    draw_text_right_scaled(right_x, y, g_ui_scale, r, g, b, text);
}


static void build_repeat(char* dst, size_t dst_sz, char ch, int count) {
    if (!dst || dst_sz == 0) return;
    if (count < 0) count = 0;
    if ((size_t)count > dst_sz - 1) count = (int)(dst_sz - 1);
    for (int i = 0; i < count; i++) dst[i] = ch;
    dst[count] = '\0';
}
static void mods_calc_layout(ModsLayout* L) {
    if (!L) return;
    memset(L, 0, sizeof(*L));

    L->w = p_mad_w ? p_mad_w() : BASE_UI_W;
    L->h = p_mad_h ? p_mad_h() : BASE_UI_H;
    L->ui = calc_ui_scale();

    // Text scale tuned for readability. We also clamp it using the current
    // window size to avoid going off-screen on tiny windows.
    {
        float s = 1.48f * L->ui; // a bit bigger than v2
        // If the window is very short, shrink slightly to keep rows visible.
        if (L->h < 520.0f) s *= 0.92f;
        if (L->h < 420.0f) s *= 0.88f;
        L->text_scale = clampf(s, 0.98f, 2.20f);
    }

    L->center_x = L->w * 0.5f;

    // Centered content area (Everest-ish), responsive to window size.
    // - On small windows we must stay within safe margins.
    // - On large windows we cap width to keep text comfortably readable.
    {
        float safe_margin = 44.0f * L->ui;
        float max_by_window = L->w - (safe_margin * 2.0f);
        float min_w = 520.0f * L->ui;
        float max_w = 980.0f * L->ui;
        float ideal = L->w * 0.70f;
        L->content_w = clampf(ideal, min_w, max_w);
        if (L->content_w > max_by_window) L->content_w = max_by_window;
        if (L->content_w < 320.0f) L->content_w = 320.0f;
    }

    L->left  = L->center_x - (L->content_w * 0.5f);
    L->right = L->center_x + (L->content_w * 0.5f);

    // Columns: label left, value right. Keep a consistent value column even
    // when content_w changes.
    {
        float pad_left = 96.0f * L->ui;
        float pad_right = 24.0f * L->ui;
        L->label_x = L->left + pad_left;
        // value_x is the start of the value column.
        L->value_x = L->left + (L->content_w * 0.60f);
        // Ensure the value column has enough breathing room.
        if (L->value_x > L->right - (180.0f * L->ui)) {
            L->value_x = L->right - (180.0f * L->ui);
        }
        // Clamp label_x to not collide with value_x on narrow windows.
        if (L->label_x > L->value_x - (90.0f * L->ui)) {
            L->label_x = L->value_x - (90.0f * L->ui);
        }
        (void)pad_right;
    }

    // List box: proportional top/bottom padding so it scales with window height.
    {
        float top_pad = (L->h * 0.18f);
        float bot_pad = (L->h * 0.14f);
        float min_top = 108.0f * L->ui;
        float min_bot = 84.0f * L->ui;
        if (top_pad < min_top) top_pad = min_top;
        if (bot_pad < min_bot) bot_pad = min_bot;
        L->list_top = top_pad;
        L->list_bottom = L->h - bot_pad;
        // Never invert.
        if (L->list_bottom < L->list_top + (80.0f * L->ui)) {
            L->list_bottom = L->list_top + (80.0f * L->ui);
        }
    }

    L->row_h = 34.0f * L->ui;
    if (L->row_h < 12.0f) L->row_h = 12.0f;
}
static int visible_rows_capacity(void) {
    ModsLayout L;
    mods_calc_layout(&L);

    // Keep g_ui_scale in sync with render/update.
    g_ui_scale = L.text_scale;

    int list_top = (int)L.list_top;
    int list_bottom = (int)L.list_bottom;
    int row_h = (int)L.row_h;

    int cap = (list_bottom - list_top) / row_h;
    if (cap < 4) cap = 4;
    return cap;
}

static void ensure_scroll_visible(void) {
    int cap = visible_rows_capacity();
    int max_scroll = (g_row_count > cap) ? (g_row_count - cap) : 0;
    int margin = (cap >= 8) ? 2 : 1;

    if (g_selected_row < 0 || g_selected_row >= g_row_count) {
        g_scroll_row = clampi(g_scroll_row, 0, max_scroll);
        return;
    }

    if (g_selected_row < g_scroll_row + margin) {
        g_scroll_row = g_selected_row - margin;
    } else if (g_selected_row > g_scroll_row + cap - margin - 1) {
        g_scroll_row = g_selected_row - (cap - margin - 1);
    }

    g_scroll_row = clampi(g_scroll_row, 0, max_scroll);
}

static void rows_clear(void) {
    g_row_count = 0;
}

static void rows_add(RowKind kind, int selectable, int mod_index, int cfg_index, const char* left, const char* right) {
    if (g_row_count >= MAX_MENU_ROWS) return;

    MenuRow* row = &g_rows[g_row_count++];
    row->kind = kind;
    row->selectable = selectable;
    row->mod_index = mod_index;
    row->cfg_index = cfg_index;
    safe_copy(row->left, sizeof(row->left), left ? left : "");
    safe_copy(row->right, sizeof(row->right), right ? right : "");
}

static int first_selectable_index(void) {
    for (int i = 0; i < g_row_count; i++) {
        if (g_rows[i].selectable) return i;
    }
    return -1;
}

static int last_selectable_index(void) {
    for (int i = g_row_count - 1; i >= 0; i--) {
        if (g_rows[i].selectable) return i;
    }
    return -1;
}

static int next_selectable(int start, int dir) {
    int i = start;
    while (1) {
        i += dir;
        if (i < 0 || i >= g_row_count) return -1;
        if (g_rows[i].selectable) return i;
    }
}

static RowKey selected_key(void) {
    RowKey k;
    k.kind = ROW_NONE;
    k.mod_index = -1;
    k.cfg_index = -1;

    if (g_selected_row >= 0 && g_selected_row < g_row_count) {
        MenuRow* row = &g_rows[g_selected_row];
        k.kind = row->kind;
        k.mod_index = row->mod_index;
        k.cfg_index = row->cfg_index;
    }
    return k;
}

static int row_matches_key(const MenuRow* row, RowKey key) {
    if (!row) return 0;
    if (row->kind != key.kind) return 0;
    if (row->mod_index != key.mod_index) return 0;
    if (row->cfg_index != key.cfg_index) return 0;
    return 1;
}

static void rebuild_rows(void) {
    RowKey keep = selected_key();
    rows_clear();

    int mod_count = lua_manager_get_mod_count();
    if (mod_count <= 0) {
        rows_add(ROW_INFO, 0, -1, -1, "No mods detected in mods/", "");
        rows_add(ROW_DIVIDER, 0, -1, -1, "", "");
    }

    for (int mi = 0; mi < mod_count; mi++) {
        char header[128];
        char version[64];
        const char* name = lua_manager_get_mod_name(mi);
        const char* id = lua_manager_get_mod_id(mi);
        const char* ver = lua_manager_get_mod_version(mi);

        if (!name || !name[0]) name = (id && id[0]) ? id : "(unnamed mod)";
        if (!ver) ver = "";

        safe_copy(header, sizeof(header), name);
        if (ver[0]) {
            snprintf(version, sizeof(version), "%s", ver);
        } else {
            version[0] = '\0';
        }

        rows_add(ROW_MOD_HEADER, 0, mi, -1, header, version);
        rows_add(ROW_DIVIDER, 0, mi, -1, "", "");

        int cfg_count = lua_manager_get_mod_config_count(mi);
        if (cfg_count <= 0) {
            rows_add(ROW_INFO, 0, mi, -1, "(no options)", "");
        }

        for (int ci = 0; ci < cfg_count; ci++) {
            char label[128];
            char value[192];
            int type = lua_manager_get_mod_config_type(mi, ci);

            const char* raw_label = lua_manager_get_mod_config_label(mi, ci);
            const char* key = lua_manager_get_mod_config_key(mi, ci);
            const char* raw_value = lua_manager_get_mod_config_value_str(mi, ci);

            if (!raw_label || !raw_label[0]) raw_label = key;
            if (!raw_label || !raw_label[0]) raw_label = "(option)";
            if (!raw_value) raw_value = "";

            safe_copy(label, sizeof(label), raw_label);

            switch (type) {
                case LUA_CFG_BOOL:
                    safe_copy(value, sizeof(value), str_bool_true(raw_value) ? "ON" : "OFF");
                    break;
                case LUA_CFG_ACTION:
                    safe_copy(value, sizeof(value), "[Run]");
                    break;
                case LUA_CFG_STRING:
                    snprintf(value, sizeof(value), "\"%s\"", raw_value);
                    break;
                default:
                    safe_copy(value, sizeof(value), raw_value);
                    break;
            }

            rows_add(ROW_CONFIG, 1, mi, ci, label, value);
        }

        if (mi != mod_count - 1) {
            rows_add(ROW_INFO, 0, -1, -1, "", "");
        }
    }

    rows_add(ROW_DIVIDER, 0, -1, -1, "", "");
    rows_add(ROW_BACK, 1, -1, -1, "Back", "");

    int found = -1;
    for (int i = 0; i < g_row_count; i++) {
        if (row_matches_key(&g_rows[i], keep)) {
            found = i;
            break;
        }
    }

    if (found >= 0) {
        g_selected_row = found;
    } else if (g_selected_row >= g_row_count) {
        g_selected_row = g_row_count - 1;
    }

    if (g_selected_row < 0 || g_selected_row >= g_row_count || !g_rows[g_selected_row].selectable) {
        int first = first_selectable_index();
        g_selected_row = first;
    }

    ensure_scroll_visible();
}

static void move_selection(int dir, int amount) {
    if (g_selected_row < 0) return;
    if (amount < 1) amount = 1;

    int prev = g_selected_row;
    int cur = g_selected_row;
    for (int i = 0; i < amount; i++) {
        int n = next_selectable(cur, dir);
        if (n < 0) break;
        cur = n;
    }

    g_selected_row = cur;
    ensure_scroll_visible();
    if (g_selected_row != prev) {
        mods_cursor_on_selection_changed();
    }
}

static void mods_go_back(void) {
    g_capture_active = 0;
    g_capture_mod = -1;
    g_capture_cfg = -1;

    void* target = g_mods_return_state;
    if (!target || target == (void*)&g_mods_state) {
        target = (void*)(uintptr_t)ADDR_OPTIONS_STATE;
    }
    p_state_switch(target);
}

static void begin_string_capture(int mod_index, int cfg_index) {
    const char* v = lua_manager_get_mod_config_value_str(mod_index, cfg_index);
    g_capture_active = 1;
    g_capture_mod = mod_index;
    g_capture_cfg = cfg_index;
    safe_copy(g_capture_buf, sizeof(g_capture_buf), v ? v : "");
}

static void apply_adjustment_on_selected(int delta) {
    if (g_selected_row < 0 || g_selected_row >= g_row_count) return;

    MenuRow* row = &g_rows[g_selected_row];
    if (row->kind != ROW_CONFIG) return;

    int type = lua_manager_get_mod_config_type(row->mod_index, row->cfg_index);
    if (type == LUA_CFG_BOOL) {
        lua_manager_config_toggle_bool(row->mod_index, row->cfg_index);
    } else if (type == LUA_CFG_INT) {
        lua_manager_config_increment_int(row->mod_index, row->cfg_index, delta);
    } else if (type == LUA_CFG_FLOAT) {
        lua_manager_config_increment_float(row->mod_index, row->cfg_index, (double)delta * 0.1);
    }

    rebuild_rows();
    mods_cursor_tick();
}

static void activate_selected(void) {
    if (g_selected_row < 0 || g_selected_row >= g_row_count) return;

    MenuRow* row = &g_rows[g_selected_row];
    if (row->kind == ROW_BACK) {
        mods_go_back();
        return;
    }

    if (row->kind != ROW_CONFIG) return;

    int type = lua_manager_get_mod_config_type(row->mod_index, row->cfg_index);
    if (type == LUA_CFG_BOOL) {
        lua_manager_config_toggle_bool(row->mod_index, row->cfg_index);
    } else if (type == LUA_CFG_INT) {
        lua_manager_config_increment_int(row->mod_index, row->cfg_index, 1);
    } else if (type == LUA_CFG_FLOAT) {
        lua_manager_config_increment_float(row->mod_index, row->cfg_index, 0.1);
    } else if (type == LUA_CFG_ACTION) {
        lua_manager_config_trigger_action(row->mod_index, row->cfg_index);
    } else if (type == LUA_CFG_STRING) {
        begin_string_capture(row->mod_index, row->cfg_index);
    }

    rebuild_rows();
}

static char* trim_ws(char* s) {
    char* end;
    if (!s) return s;
    while (*s && isspace((unsigned char)*s)) s++;
    end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) end--;
    *end = '\0';
    return s;
}

static void console_clear_output(void) {
    g_console_line_head = 0;
    g_console_line_count = 0;
    g_console_scroll = 0;
}

static ConsoleLine* console_line_at_oldest_index(int idx) {
    int first;
    int slot;
    if (idx < 0 || idx >= g_console_line_count) return NULL;
    first = g_console_line_head - g_console_line_count;
    while (first < 0) first += CONSOLE_MAX_LINES;
    slot = first + idx;
    while (slot >= CONSOLE_MAX_LINES) slot -= CONSOLE_MAX_LINES;
    return &g_console_lines[slot];
}

static void console_push_line_rgb(const char* text, float r, float g, float b) {
    ConsoleLine* line = &g_console_lines[g_console_line_head];
    safe_copy(line->text, sizeof(line->text), text ? text : "");
    line->r = r;
    line->g = g;
    line->b = b;

    g_console_line_head++;
    if (g_console_line_head >= CONSOLE_MAX_LINES) g_console_line_head = 0;
    if (g_console_line_count < CONSOLE_MAX_LINES) g_console_line_count++;
    g_console_scroll = 0;
}

static void console_push_command_line(const char* cmd) {
    char line[CONSOLE_LINE_TEXT];
    snprintf(line, sizeof(line), "> %s", cmd ? cmd : "");
    console_push_line_rgb(line, 0.95f, 0.86f, 0.34f);
}

static void console_history_add(const char* cmd) {
    int i;
    if (!cmd || !cmd[0]) return;

    if (g_console_history_count > 0) {
        const char* last = g_console_history[g_console_history_count - 1];
        if (_stricmp(last, cmd) == 0) return;
    }

    if (g_console_history_count >= CONSOLE_HISTORY_MAX) {
        for (i = 1; i < CONSOLE_HISTORY_MAX; i++) {
            safe_copy(g_console_history[i - 1], sizeof(g_console_history[0]), g_console_history[i]);
        }
        g_console_history_count = CONSOLE_HISTORY_MAX - 1;
    }

    safe_copy(g_console_history[g_console_history_count], sizeof(g_console_history[0]), cmd);
    g_console_history_count++;
}

static void console_reset_history_nav(void) {
    g_console_history_pos = -1;
    g_console_has_edit_stash = 0;
    g_console_edit_stash[0] = '\0';
}

static void console_set_input(const char* s) {
    size_t len;
    safe_copy(g_console_input, sizeof(g_console_input), s ? s : "");
    len = strlen(g_console_input);
    g_console_cursor = (int)len;
}

static void console_detach_from_history(void) {
    if (g_console_history_pos == -1) return;
    g_console_history_pos = -1;
    g_console_has_edit_stash = 0;
    g_console_edit_stash[0] = '\0';
}

static void console_history_step(int dir) {
    if (g_console_history_count <= 0) return;

    if (dir < 0) {
        if (g_console_history_pos == -1) {
            safe_copy(g_console_edit_stash, sizeof(g_console_edit_stash), g_console_input);
            g_console_has_edit_stash = 1;
            g_console_history_pos = g_console_history_count - 1;
        } else if (g_console_history_pos > 0) {
            g_console_history_pos--;
        }
        console_set_input(g_console_history[g_console_history_pos]);
    } else {
        if (g_console_history_pos == -1) return;
        if (g_console_history_pos < g_console_history_count - 1) {
            g_console_history_pos++;
            console_set_input(g_console_history[g_console_history_pos]);
            return;
        }
        g_console_history_pos = -1;
        if (g_console_has_edit_stash) console_set_input(g_console_edit_stash);
        else console_set_input("");
        g_console_has_edit_stash = 0;
    }
}

static void console_insert_text(const char* text) {
    size_t len;
    size_t ins_len;
    if (!text || !text[0]) return;
    len = strlen(g_console_input);
    ins_len = strlen(text);
    if ((size_t)g_console_cursor > len) g_console_cursor = (int)len;
    if (ins_len > (sizeof(g_console_input) - 1) - len) {
        ins_len = (sizeof(g_console_input) - 1) - len;
    }
    if (ins_len <= 0) return;
    console_detach_from_history();
    memmove(g_console_input + g_console_cursor + ins_len,
            g_console_input + g_console_cursor,
            len - (size_t)g_console_cursor + 1);
    memcpy(g_console_input + g_console_cursor, text, ins_len);
    g_console_cursor += (int)ins_len;
}

static void console_backspace(void) {
    size_t len = strlen(g_console_input);
    if (g_console_cursor <= 0 || len <= 0) return;
    console_detach_from_history();
    memmove(g_console_input + g_console_cursor - 1,
            g_console_input + g_console_cursor,
            len - (size_t)g_console_cursor + 1);
    g_console_cursor--;
}

static void console_delete(void) {
    size_t len = strlen(g_console_input);
    if ((size_t)g_console_cursor >= len) return;
    console_detach_from_history();
    memmove(g_console_input + g_console_cursor,
            g_console_input + g_console_cursor + 1,
            len - (size_t)g_console_cursor);
}

static void console_scroll_by(int delta) {
    int max_scroll = g_console_line_count > 0 ? g_console_line_count - 1 : 0;
    g_console_scroll += delta;
    if (g_console_scroll < 0) g_console_scroll = 0;
    if (g_console_scroll > max_scroll) g_console_scroll = max_scroll;
}

static void console_downsample_rgba(const unsigned char* src, int sw, int sh, unsigned char* dst, int dw, int dh) {
    int y;
    int x;
    if (!src || !dst || sw <= 0 || sh <= 0 || dw <= 0 || dh <= 0) return;

    for (y = 0; y < dh; y++) {
        int sy0 = (y * sh) / dh;
        int sy1 = ((y + 1) * sh) / dh;
        if (sy1 <= sy0) sy1 = sy0 + 1;
        if (sy1 > sh) sy1 = sh;

        for (x = 0; x < dw; x++) {
            int sx0 = (x * sw) / dw;
            int sx1 = ((x + 1) * sw) / dw;
            uint64_t ar = 0, ag = 0, ab = 0, aa = 0, count = 0;
            int sy;
            int sx;
            if (sx1 <= sx0) sx1 = sx0 + 1;
            if (sx1 > sw) sx1 = sw;

            for (sy = sy0; sy < sy1; sy++) {
                const unsigned char* row = src + ((size_t)sy * (size_t)sw * 4);
                for (sx = sx0; sx < sx1; sx++) {
                    const unsigned char* p = row + ((size_t)sx * 4);
                    ar += p[0];
                    ag += p[1];
                    ab += p[2];
                    aa += p[3];
                    count++;
                }
            }

            if (count == 0) count = 1;
            dst[((size_t)y * (size_t)dw + (size_t)x) * 4 + 0] = (unsigned char)(ar / count);
            dst[((size_t)y * (size_t)dw + (size_t)x) * 4 + 1] = (unsigned char)(ag / count);
            dst[((size_t)y * (size_t)dw + (size_t)x) * 4 + 2] = (unsigned char)(ab / count);
            dst[((size_t)y * (size_t)dw + (size_t)x) * 4 + 3] = (unsigned char)(aa / count);
        }
    }
}

static void console_box_blur_rgba(const unsigned char* src, unsigned char* dst, int w, int h, int radius) {
    int y;
    int x;
    if (!src || !dst || w <= 0 || h <= 0 || radius <= 0) return;
    for (y = 0; y < h; y++) {
        for (x = 0; x < w; x++) {
            uint64_t ar = 0, ag = 0, ab = 0, aa = 0, count = 0;
            int ky;
            for (ky = -radius; ky <= radius; ky++) {
                int sy = y + ky;
                int kx;
                if (sy < 0) sy = 0;
                if (sy >= h) sy = h - 1;
                for (kx = -radius; kx <= radius; kx++) {
                    int sx = x + kx;
                    const unsigned char* p;
                    if (sx < 0) sx = 0;
                    if (sx >= w) sx = w - 1;
                    p = src + ((size_t)sy * (size_t)w + (size_t)sx) * 4;
                    ar += p[0];
                    ag += p[1];
                    ab += p[2];
                    aa += p[3];
                    count++;
                }
            }
            if (count == 0) count = 1;
            dst[((size_t)y * (size_t)w + (size_t)x) * 4 + 0] = (unsigned char)(ar / count);
            dst[((size_t)y * (size_t)w + (size_t)x) * 4 + 1] = (unsigned char)(ag / count);
            dst[((size_t)y * (size_t)w + (size_t)x) * 4 + 2] = (unsigned char)(ab / count);
            dst[((size_t)y * (size_t)w + (size_t)x) * 4 + 3] = (unsigned char)(aa / count);
        }
    }
}

static int console_capture_background_now(void) {
    int w = (int)(p_mad_w ? p_mad_w() : BASE_UI_W);
    int h = (int)(p_mad_h ? p_mad_h() : BASE_UI_H);
    int bw;
    int bh;
    GLint prev_pack_alignment = 4;
    GLint prev_read_buffer = GL_BACK;
    GLint prev_tex_binding_2d = 0;
    unsigned char* src;
    unsigned char* small;
    unsigned char* blur_tmp;

    if (w < 2 || h < 2) return 0;
    bw = w / CONSOLE_BG_DOWNSAMPLE;
    bh = h / CONSOLE_BG_DOWNSAMPLE;
    if (bw < 16) bw = 16;
    if (bh < 16) bh = 16;

    src = (unsigned char*)malloc((size_t)w * (size_t)h * 4);
    small = (unsigned char*)malloc((size_t)bw * (size_t)bh * 4);
    blur_tmp = (unsigned char*)malloc((size_t)bw * (size_t)bh * 4);
    if (!src || !small || !blur_tmp) {
        free(src);
        free(small);
        free(blur_tmp);
        return 0;
    }

    glGetIntegerv(GL_PACK_ALIGNMENT, &prev_pack_alignment);
    glGetIntegerv(GL_READ_BUFFER, &prev_read_buffer);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev_tex_binding_2d);

    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadBuffer(GL_BACK);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, src);

    console_downsample_rgba(src, w, h, small, bw, bh);
    console_box_blur_rgba(small, blur_tmp, bw, bh, 1);
    console_box_blur_rgba(blur_tmp, small, bw, bh, 1);

    if (!g_console_bg_tex) {
        glGenTextures(1, &g_console_bg_tex);
    }
    glBindTexture(GL_TEXTURE_2D, g_console_bg_tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
#ifdef GL_CLAMP_TO_EDGE
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
#else
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
#endif
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, bw, bh, 0, GL_RGBA, GL_UNSIGNED_BYTE, small);

    g_console_bg_w = bw;
    g_console_bg_h = bh;
    g_console_bg_ready = 1;

    glPixelStorei(GL_PACK_ALIGNMENT, prev_pack_alignment);
    glReadBuffer(prev_read_buffer);
    glBindTexture(GL_TEXTURE_2D, (GLuint)prev_tex_binding_2d);

    free(src);
    free(small);
    free(blur_tmp);
    return 1;
}

static void console_open(void) {
    void* cur;
    if (!p_state_switch) return;
    if (is_console_state_active()) return;
    if (g_console_open_pending || g_console_open_ready) return;

    cur = p_state_current ? p_state_current() : NULL;
    if (!cur || cur == (void*)&g_console_state) {
        cur = (void*)(uintptr_t)ADDR_MAIN_STATE;
    } else if (cur == (void*)&g_mods_entry_state) {
        cur = (void*)(uintptr_t)ADDR_OPTIONS_STATE;
    }

    g_console_pending_return_state = cur;
    g_console_open_pending = 1;
    g_console_open_ready = 0;
    g_console_suppress_next_textinput = 1;
}

static void console_close(void) {
    void* target = g_console_return_state;
    g_console_open_pending = 0;
    g_console_open_ready = 0;
    if (!p_state_switch) return;
    if (!target || target == (void*)&g_console_state) {
        target = (void*)(uintptr_t)ADDR_MAIN_STATE;
    }
    p_state_switch(target);
}

static int console_find_mod_index_by_id(const char* id) {
    int count = lua_manager_get_mod_count();
    if (!id || !id[0]) return -1;
    for (int i = 0; i < count; i++) {
        const char* mid = lua_manager_get_mod_id(i);
        if (mid && _stricmp(mid, id) == 0) return i;
    }
    return -1;
}

static const char* console_cfg_type_name(int type) {
    switch (type) {
        case LUA_CFG_BOOL: return "bool";
        case LUA_CFG_INT: return "int";
        case LUA_CFG_FLOAT: return "float";
        case LUA_CFG_STRING: return "string";
        case LUA_CFG_ACTION: return "action";
        default: return "unknown";
    }
}

static const char* console_stristr(const char* haystack, const char* needle) {
    const char* h;
    size_t nlen;
    if (!haystack || !needle) return NULL;
    if (!needle[0]) return haystack;
    nlen = strlen(needle);
    for (h = haystack; *h; h++) {
        size_t i;
        for (i = 0; i < nlen; i++) {
            unsigned char hc = (unsigned char)h[i];
            unsigned char nc = (unsigned char)needle[i];
            if (!hc) break;
            if (tolower(hc) != tolower(nc)) break;
        }
        if (i == nlen) return h;
    }
    return NULL;
}

static char* console_parse_token(char** inout_cursor) {
    char* s;
    char* tok;
    char quote;
    if (!inout_cursor || !*inout_cursor) return NULL;
    s = trim_ws(*inout_cursor);
    if (!s || !s[0]) {
        *inout_cursor = s;
        return NULL;
    }

    if (*s == '"' || *s == '\'') {
        quote = *s;
        s++;
        tok = s;
        while (*s && *s != quote) s++;
        if (*s == quote) {
            *s = '\0';
            s++;
        }
        *inout_cursor = s;
        return tok;
    }

    tok = s;
    while (*s && !isspace((unsigned char)*s)) s++;
    if (*s) {
        *s = '\0';
        s++;
    }
    *inout_cursor = s;
    return tok;
}

static int console_try_parse_long(const char* s, long* out_value) {
    char* end = NULL;
    long v;
    if (!s) return 0;
    while (*s && isspace((unsigned char)*s)) s++;
    if (!s[0]) return 0;
    v = strtol(s, &end, 0);
    if (end == s) return 0;
    while (*end && isspace((unsigned char)*end)) end++;
    if (*end) return 0;
    if (out_value) *out_value = v;
    return 1;
}

static int console_try_parse_double(const char* s, double* out_value) {
    char* end = NULL;
    double v;
    if (!s) return 0;
    while (*s && isspace((unsigned char)*s)) s++;
    if (!s[0]) return 0;
    v = strtod(s, &end);
    if (end == s) return 0;
    while (*end && isspace((unsigned char)*end)) end++;
    if (*end) return 0;
    if (out_value) *out_value = v;
    return 1;
}

static int console_try_parse_bool(const char* s, int* out_value) {
    if (!s || !s[0]) return 0;
    if (str_bool_true(s)) {
        if (out_value) *out_value = 1;
        return 1;
    }
    if (str_bool_false(s)) {
        if (out_value) *out_value = 0;
        return 1;
    }
    return 0;
}

static void console_strip_crlf(char* s) {
    size_t len;
    if (!s) return;
    len = strlen(s);
    while (len > 0 && (s[len - 1] == '\r' || s[len - 1] == '\n')) {
        s[len - 1] = '\0';
        len--;
    }
}

static void console_show_help(const char* topic) {
    char topic_buf[CONSOLE_INPUT_BUF];
    const char* t = "";
    if (topic && topic[0]) {
        safe_copy(topic_buf, sizeof(topic_buf), topic);
        t = trim_ws(topic_buf);
    }
    if (!t || !t[0]) {
        console_push_line_rgb("Commands:", 0.72f, 0.90f, 1.00f);
        console_push_line_rgb("  help [topic]", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  commands", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  clear", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  history [count]", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  echo <text>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  console.stats", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  state", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  state.last", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  state.return [main|main_initial|options|options_paused|mods|mods_entry]", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  state.switch <main|main_initial|options|options_paused|mods|mods_entry|console|return>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  sys.info", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  ui.size", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  time.scale [value|auto]", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  framework.api", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.count", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.list", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.find <text>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.info <id>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.enable <id|all>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.disable <id|all>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.toggle <id|all>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.config <id>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.config.find <text>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.config.get <id> <key>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.config.set <id> <key> <value>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.config.action <id> <key>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  reload.mods", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  mods.reload", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  reload.assets", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  log.level [debug|info|warn|error]", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  log.tail [lines]", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  input.show [player]", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  input.override <player> <mask> [frames] [replace]", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  input.clear <player>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  lua <code>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  eval <code>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  lua.mod <id> <code>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  eval.mod <id> <code>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  lua.file <path>", 0.87f, 0.87f, 0.87f);
        console_push_line_rgb("  exit", 0.87f, 0.87f, 0.87f);
        return;
    }

    if (_stricmp(t, "mods.config.set") == 0) {
        console_push_line_rgb("mods.config.set <id> <key> <value>: set bool/int/float/string config by key.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "mods.config.action") == 0) {
        console_push_line_rgb("mods.config.action <id> <key>: trigger an action config entry.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "mods.info") == 0) {
        console_push_line_rgb("mods.info <id>: show name/version/enabled/config-count.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "mods.toggle") == 0) {
        console_push_line_rgb("mods.toggle <id|all>: invert enabled state.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "mods.config.find") == 0) {
        console_push_line_rgb("mods.config.find <text>: search mod config keys/labels/values.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "log.level") == 0) {
        console_push_line_rgb("log.level <debug|info|warn|error>: set framework log threshold.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "log.tail") == 0) {
        console_push_line_rgb("log.tail [lines]: show last lines from mods/modframework.log.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "time.scale") == 0) {
        console_push_line_rgb("time.scale: show current timescale.", 0.72f, 0.90f, 1.00f);
        console_push_line_rgb("time.scale <value>: set manual timescale (0.05..100).", 0.72f, 0.90f, 1.00f);
        console_push_line_rgb("time.scale auto: clear manual override.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "reload.assets") == 0) {
        console_push_line_rgb("reload.assets: reload tracked texture/font overlays and rebuild atlases.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "reload.mods") == 0) {
        console_push_line_rgb("reload.mods: unload+reload all mods and refresh runtime.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "input.override") == 0) {
        console_push_line_rgb("input.override <player> <mask> [frames] [replace]: force command bits.", 0.72f, 0.90f, 1.00f);
        console_push_line_rgb("mask supports decimal or hex (example: 0x10). frames<0 means persistent.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "state.switch") == 0) {
        console_push_line_rgb("state.switch <name>: switch to main/main_initial/options/options_paused/mods/mods_entry/console/return.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "state.return") == 0) {
        console_push_line_rgb("state.return [main|main_initial|options|options_paused|mods|mods_entry]: show/set return state.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "lua") == 0) {
        console_push_line_rgb("lua <code>: execute Lua code in global runtime.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "lua.mod") == 0) {
        console_push_line_rgb("lua.mod <id> <code>: execute Lua code in a mod environment.", 0.72f, 0.90f, 1.00f);
        return;
    }
    if (_stricmp(t, "lua.file") == 0) {
        console_push_line_rgb("lua.file <path>: execute a Lua file in global runtime.", 0.72f, 0.90f, 1.00f);
        return;
    }

    {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "No detailed help for topic: %s", t);
        console_push_line_rgb(out, 0.98f, 0.76f, 0.40f);
    }
}

static void console_show_history(const char* count_arg) {
    int limit = 20;
    int start;
    if (count_arg && count_arg[0]) {
        long parsed = 0;
        if (!console_try_parse_long(count_arg, &parsed) || parsed <= 0) {
            console_push_line_rgb("Usage: history [positive_count]", 0.98f, 0.76f, 0.40f);
            return;
        }
        if (parsed > CONSOLE_HISTORY_MAX) parsed = CONSOLE_HISTORY_MAX;
        limit = (int)parsed;
    }
    if (g_console_history_count <= 0) {
        console_push_line_rgb("(history empty)", 0.62f, 0.70f, 0.82f);
        return;
    }
    start = g_console_history_count > limit ? (g_console_history_count - limit) : 0;
    for (int i = start; i < g_console_history_count; i++) {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "%2d: %s", i + 1, g_console_history[i]);
        console_push_line_rgb(out, 0.80f, 0.83f, 0.90f);
    }
}

static void console_show_console_stats(void) {
    char out[CONSOLE_LINE_TEXT];
    snprintf(out, sizeof(out),
             "console.stats: lines=%d/%d history=%d/%d scroll=%d cursor=%d input_len=%d",
             g_console_line_count, CONSOLE_MAX_LINES,
             g_console_history_count, CONSOLE_HISTORY_MAX,
             g_console_scroll, g_console_cursor, (int)strlen(g_console_input));
    console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
}

static void console_echo(const char* text) {
    console_push_line_rgb((text && text[0]) ? text : "", 0.80f, 0.83f, 0.90f);
}

static void console_show_state(void) {
    void* cur = p_state_current ? p_state_current() : NULL;
    char out[CONSOLE_LINE_TEXT];
    snprintf(out, sizeof(out), "current=%s (%p) return=%s (%p)",
             state_name_from_ptr(cur), cur,
             state_name_from_ptr(g_console_return_state), g_console_return_state);
    console_push_line_rgb(out, 0.60f, 0.88f, 0.72f);
}

static void* console_state_ptr_from_name(const char* name, int allow_return_alias) {
    if (!name || !name[0]) return NULL;
    if (_stricmp(name, "main") == 0) return (void*)(uintptr_t)ADDR_MAIN_STATE;
    if (_stricmp(name, "main_initial") == 0) return (void*)(uintptr_t)ADDR_MAIN_STATE_INITIAL;
    if (_stricmp(name, "options") == 0) return (void*)(uintptr_t)ADDR_OPTIONS_STATE;
    if (_stricmp(name, "options_paused") == 0) return (void*)(uintptr_t)ADDR_OPTIONS_STATE_PAUSED;
    if (_stricmp(name, "mods") == 0) return (void*)&g_mods_state;
    if (_stricmp(name, "mods_entry") == 0) return (void*)&g_mods_entry_state;
    if (_stricmp(name, "console") == 0) return (void*)&g_console_state;
    if (allow_return_alias && _stricmp(name, "return") == 0) return g_console_return_state;
    return NULL;
}

static void console_show_last_state(void) {
    void* st = p_state_last ? p_state_last() : NULL;
    char out[CONSOLE_LINE_TEXT];
    snprintf(out, sizeof(out), "last=%s (%p)", state_name_from_ptr(st), st);
    console_push_line_rgb(out, 0.60f, 0.88f, 0.72f);
}

static void console_show_return_state(void) {
    char out[CONSOLE_LINE_TEXT];
    snprintf(out, sizeof(out), "return=%s (%p)", state_name_from_ptr(g_console_return_state), g_console_return_state);
    console_push_line_rgb(out, 0.60f, 0.88f, 0.72f);
}

static void console_set_return_state(const char* state_arg) {
    char name_buf[CONSOLE_INPUT_BUF];
    char* name;
    void* target;
    char out[CONSOLE_LINE_TEXT];

    safe_copy(name_buf, sizeof(name_buf), state_arg ? state_arg : "");
    name = trim_ws(name_buf);
    if (!name || !name[0]) {
        console_show_return_state();
        return;
    }

    target = console_state_ptr_from_name(name, 0);
    if (!target || target == (void*)&g_console_state) {
        console_push_line_rgb("Usage: state.return [main|main_initial|options|options_paused|mods|mods_entry]", 0.98f, 0.76f, 0.40f);
        return;
    }

    g_console_return_state = target;
    snprintf(out, sizeof(out), "state.return -> %s", state_name_from_ptr(target));
    console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
}

static void console_switch_state(const char* state_arg) {
    char name_buf[CONSOLE_INPUT_BUF];
    char* name;
    void* target;
    safe_copy(name_buf, sizeof(name_buf), state_arg ? state_arg : "");
    name = trim_ws(name_buf);
    if (!name || !name[0]) {
        console_push_line_rgb("Usage: state.switch <main|main_initial|options|options_paused|mods|mods_entry|console|return>", 0.98f, 0.76f, 0.40f);
        return;
    }
    if (!p_state_switch) {
        console_push_line_rgb("state.switch unavailable: missing state switch pointer", 0.98f, 0.45f, 0.45f);
        return;
    }

    target = console_state_ptr_from_name(name, 1);
    if (!target) {
        console_push_line_rgb("Unknown state. Use: main/main_initial/options/options_paused/mods/mods_entry/console/return", 0.98f, 0.76f, 0.40f);
        return;
    }

    p_state_switch(target);
    {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "state.switch -> %s", state_name_from_ptr(target));
        console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
    }
}

static void console_show_ui_size(void) {
    float w = p_mad_w ? p_mad_w() : BASE_UI_W;
    float h = p_mad_h ? p_mad_h() : BASE_UI_H;
    float ui = calc_ui_scale();
    char out[CONSOLE_LINE_TEXT];
    snprintf(out, sizeof(out), "ui.size: %.1fx%.1f ui_scale=%.3f", w, h, ui);
    console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
}

static void console_show_system_info(void) {
    char out[CONSOLE_LINE_TEXT];
    int manual_ts = lua_manager_get_time_scale_manual(NULL);
    snprintf(out, sizeof(out), "framework.api=%d mods=%d state=%s time.scale=%.3f%s log=%s",
             lua_manager_framework_api(),
             lua_manager_get_mod_count(),
             state_name_from_ptr(p_state_current ? p_state_current() : NULL),
             (double)lua_manager_get_time_scale(),
             manual_ts ? "(manual)" : "",
             log_get_level_name());
    console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
    console_show_ui_size();
}

static void console_show_mods_count(void) {
    char out[CONSOLE_LINE_TEXT];
    snprintf(out, sizeof(out), "mods.count: %d", lua_manager_get_mod_count());
    console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
}

static void console_show_mods_list(void) {
    int count = lua_manager_get_mod_count();
    if (count <= 0) {
        console_push_line_rgb("No mods loaded.", 0.62f, 0.70f, 0.82f);
        return;
    }
    for (int i = 0; i < count; i++) {
        const char* id = lua_manager_get_mod_id(i);
        const char* name = lua_manager_get_mod_name(i);
        const char* ver = lua_manager_get_mod_version(i);
        int enabled = lua_manager_get_mod_enabled(i);
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "[%s] %s (%s) id=%s",
                 enabled ? "on" : "off",
                 name ? name : "",
                 ver ? ver : "",
                 id ? id : "");
        console_push_line_rgb(out, enabled ? 0.64f : 0.72f, enabled ? 0.92f : 0.72f, enabled ? 0.66f : 0.72f);
    }
}

static void console_find_mods(const char* query) {
    int count = lua_manager_get_mod_count();
    int found = 0;
    if (!query || !query[0]) {
        console_push_line_rgb("Usage: mods.find <text>", 0.98f, 0.76f, 0.40f);
        return;
    }
    for (int i = 0; i < count; i++) {
        const char* id = lua_manager_get_mod_id(i);
        const char* name = lua_manager_get_mod_name(i);
        const char* ver = lua_manager_get_mod_version(i);
        if (console_stristr(id, query) || console_stristr(name, query) || console_stristr(ver, query)) {
            char out[CONSOLE_LINE_TEXT];
            snprintf(out, sizeof(out), "[%s] %s (%s) id=%s",
                     lua_manager_get_mod_enabled(i) ? "on" : "off",
                     name ? name : "",
                     ver ? ver : "",
                     id ? id : "");
            console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
            found++;
        }
    }
    if (!found) {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "mods.find: no matches for '%s'", query);
        console_push_line_rgb(out, 0.98f, 0.76f, 0.40f);
    }
}

static void console_show_mod_info(const char* id) {
    int idx;
    char out[CONSOLE_LINE_TEXT];
    if (!id || !id[0]) {
        console_push_line_rgb("Usage: mods.info <id>", 0.98f, 0.76f, 0.40f);
        return;
    }

    idx = console_find_mod_index_by_id(id);
    if (idx < 0) {
        snprintf(out, sizeof(out), "Mod not found: %s", id);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
        return;
    }

    snprintf(out, sizeof(out), "id=%s name=%s version=%s enabled=%s cfg=%d",
             lua_manager_get_mod_id(idx),
             lua_manager_get_mod_name(idx),
             lua_manager_get_mod_version(idx),
             lua_manager_get_mod_enabled(idx) ? "true" : "false",
             lua_manager_get_mod_config_count(idx));
    console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
}

static void console_set_mod_enabled(const char* id, int enabled) {
    int idx;
    char out[CONSOLE_LINE_TEXT];
    if (!id || !id[0]) {
        console_push_line_rgb(enabled ? "Usage: mods.enable <id|all>" : "Usage: mods.disable <id|all>", 0.98f, 0.76f, 0.40f);
        return;
    }
    if (_stricmp(id, "all") == 0) {
        int count = lua_manager_get_mod_count();
        int changed = 0;
        for (int i = 0; i < count; i++) {
            if (lua_manager_get_mod_enabled(i) == (enabled ? 1 : 0)) continue;
            lua_manager_set_mod_enabled(i, enabled ? 1 : 0);
            changed++;
        }
        snprintf(out, sizeof(out), "%s all: changed=%d total=%d",
                 enabled ? "mods.enable" : "mods.disable", changed, count);
        console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
        return;
    }
    idx = console_find_mod_index_by_id(id);
    if (idx < 0) {
        snprintf(out, sizeof(out), "Mod not found: %s", id);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
        return;
    }
    lua_manager_set_mod_enabled(idx, enabled ? 1 : 0);
    snprintf(out, sizeof(out), "%s: %s",
             enabled ? "mods.enable" : "mods.disable",
             lua_manager_get_mod_id(idx));
    console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
}

static void console_toggle_mod_enabled(const char* id) {
    char out[CONSOLE_LINE_TEXT];
    if (!id || !id[0]) {
        console_push_line_rgb("Usage: mods.toggle <id|all>", 0.98f, 0.76f, 0.40f);
        return;
    }
    if (_stricmp(id, "all") == 0) {
        int count = lua_manager_get_mod_count();
        int on_count = 0;
        int off_count = 0;
        for (int i = 0; i < count; i++) {
            int new_enabled = lua_manager_get_mod_enabled(i) ? 0 : 1;
            lua_manager_set_mod_enabled(i, new_enabled);
            if (new_enabled) on_count++;
            else off_count++;
        }
        snprintf(out, sizeof(out), "mods.toggle all: now_on=%d now_off=%d total=%d", on_count, off_count, count);
        console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
        return;
    }
    {
        int idx = console_find_mod_index_by_id(id);
        if (idx < 0) {
            snprintf(out, sizeof(out), "Mod not found: %s", id);
            console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
            return;
        }
        {
            int new_enabled = lua_manager_get_mod_enabled(idx) ? 0 : 1;
            lua_manager_set_mod_enabled(idx, new_enabled);
            snprintf(out, sizeof(out), "mods.toggle: %s -> %s",
                     lua_manager_get_mod_id(idx),
                     new_enabled ? "on" : "off");
            console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
        }
    }
}

static void console_show_mod_config(const char* id) {
    int idx;
    int cfg_count;
    if (!id || !id[0]) {
        console_push_line_rgb("Usage: mods.config <id>", 0.98f, 0.76f, 0.40f);
        return;
    }
    idx = console_find_mod_index_by_id(id);
    if (idx < 0) {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "Mod not found: %s", id);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
        return;
    }

    cfg_count = lua_manager_get_mod_config_count(idx);
    {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "mods.config %s: %d entries", lua_manager_get_mod_id(idx), cfg_count);
        console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
    }
    if (cfg_count <= 0) return;

    for (int ci = 0; ci < cfg_count; ci++) {
        const char* key = lua_manager_get_mod_config_key(idx, ci);
        const char* val = lua_manager_get_mod_config_value_str(idx, ci);
        const char* label = lua_manager_get_mod_config_label(idx, ci);
        int type = lua_manager_get_mod_config_type(idx, ci);
        char out[CONSOLE_LINE_TEXT];
        if (label && label[0] && _stricmp(label, key) != 0) {
            snprintf(out, sizeof(out), "  %s (%s) = %s [%s]",
                     key ? key : "", console_cfg_type_name(type),
                     val ? val : "", label);
        } else {
            snprintf(out, sizeof(out), "  %s (%s) = %s",
                     key ? key : "", console_cfg_type_name(type),
                     val ? val : "");
        }
        console_push_line_rgb(out, 0.80f, 0.83f, 0.90f);
    }
}

static void console_find_mod_config(const char* query) {
    int match_count = 0;
    if (!query || !query[0]) {
        console_push_line_rgb("Usage: mods.config.find <text>", 0.98f, 0.76f, 0.40f);
        return;
    }

    for (int mi = 0; mi < lua_manager_get_mod_count(); mi++) {
        const char* mod_id = lua_manager_get_mod_id(mi);
        int cfg_count = lua_manager_get_mod_config_count(mi);
        for (int ci = 0; ci < cfg_count; ci++) {
            const char* key = lua_manager_get_mod_config_key(mi, ci);
            const char* label = lua_manager_get_mod_config_label(mi, ci);
            const char* value = lua_manager_get_mod_config_value_str(mi, ci);
            if (!console_stristr(mod_id, query) &&
                !console_stristr(key, query) &&
                !console_stristr(label, query) &&
                !console_stristr(value, query)) {
                continue;
            }
            {
                char out[CONSOLE_LINE_TEXT];
                snprintf(out, sizeof(out), "%s.%s (%s) = %s",
                         mod_id ? mod_id : "",
                         key ? key : "",
                         console_cfg_type_name(lua_manager_get_mod_config_type(mi, ci)),
                         value ? value : "");
                console_push_line_rgb(out, 0.80f, 0.83f, 0.90f);
            }
            match_count++;
        }
    }

    if (match_count == 0) {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "mods.config.find: no matches for '%s'", query);
        console_push_line_rgb(out, 0.98f, 0.76f, 0.40f);
    } else {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "mods.config.find: %d match(es)", match_count);
        console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
    }
}

static int console_find_cfg_index_by_key(int mod_index, const char* key) {
    return lua_manager_find_mod_config_index(mod_index, key);
}

static void console_show_mod_config_value(const char* id, const char* key) {
    int idx;
    int cfg_idx;
    char out[CONSOLE_LINE_TEXT];
    if (!id || !id[0] || !key || !key[0]) {
        console_push_line_rgb("Usage: mods.config.get <id> <key>", 0.98f, 0.76f, 0.40f);
        return;
    }
    idx = console_find_mod_index_by_id(id);
    if (idx < 0) {
        snprintf(out, sizeof(out), "Mod not found: %s", id);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
        return;
    }
    cfg_idx = console_find_cfg_index_by_key(idx, key);
    if (cfg_idx < 0) {
        snprintf(out, sizeof(out), "Config key not found: %s", key);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
        return;
    }

    snprintf(out, sizeof(out), "%s.%s (%s) = %s",
             lua_manager_get_mod_id(idx),
             lua_manager_get_mod_config_key(idx, cfg_idx),
             console_cfg_type_name(lua_manager_get_mod_config_type(idx, cfg_idx)),
             lua_manager_get_mod_config_value_str(idx, cfg_idx));
    console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
}

static void console_set_mod_config_value(const char* id, const char* key, const char* value) {
    int idx;
    int cfg_idx;
    int type;
    int ok = 0;
    char out[CONSOLE_LINE_TEXT];
    if (!id || !id[0] || !key || !key[0] || !value) {
        console_push_line_rgb("Usage: mods.config.set <id> <key> <value>", 0.98f, 0.76f, 0.40f);
        return;
    }
    idx = console_find_mod_index_by_id(id);
    if (idx < 0) {
        snprintf(out, sizeof(out), "Mod not found: %s", id);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
        return;
    }
    cfg_idx = console_find_cfg_index_by_key(idx, key);
    if (cfg_idx < 0) {
        snprintf(out, sizeof(out), "Config key not found: %s", key);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
        return;
    }

    type = lua_manager_get_mod_config_type(idx, cfg_idx);
    if (type == LUA_CFG_BOOL) {
        int want = 0;
        int cur = str_bool_true(lua_manager_get_mod_config_value_str(idx, cfg_idx)) ? 1 : 0;
        if (!console_try_parse_bool(value, &want)) {
            console_push_line_rgb("Bool value must be true/false/on/off/1/0", 0.98f, 0.76f, 0.40f);
            return;
        }
        ok = (want == cur) ? 1 : lua_manager_config_toggle_bool(idx, cfg_idx);
    } else if (type == LUA_CFG_INT) {
        long want = 0;
        long cur = 0;
        const char* cur_text = lua_manager_get_mod_config_value_str(idx, cfg_idx);
        if (!console_try_parse_long(value, &want)) {
            console_push_line_rgb("Int value is invalid", 0.98f, 0.76f, 0.40f);
            return;
        }
        if (!console_try_parse_long(cur_text, &cur)) cur = strtol(cur_text, NULL, 10);
        ok = lua_manager_config_increment_int(idx, cfg_idx, (int)(want - cur));
    } else if (type == LUA_CFG_FLOAT) {
        double want = 0.0;
        double cur = 0.0;
        const char* cur_text = lua_manager_get_mod_config_value_str(idx, cfg_idx);
        if (!console_try_parse_double(value, &want)) {
            console_push_line_rgb("Float value is invalid", 0.98f, 0.76f, 0.40f);
            return;
        }
        if (!console_try_parse_double(cur_text, &cur)) cur = atof(cur_text);
        ok = lua_manager_config_increment_float(idx, cfg_idx, want - cur);
    } else if (type == LUA_CFG_STRING) {
        ok = lua_manager_config_set_string(idx, cfg_idx, value);
    } else if (type == LUA_CFG_ACTION) {
        console_push_line_rgb("Use mods.config.action for action config keys.", 0.98f, 0.76f, 0.40f);
        return;
    } else {
        console_push_line_rgb("Unsupported config type", 0.98f, 0.76f, 0.40f);
        return;
    }

    if (!ok) {
        console_push_line_rgb("Config update failed (see modframework.log)", 0.98f, 0.45f, 0.45f);
        return;
    }

    snprintf(out, sizeof(out), "%s.%s = %s",
             lua_manager_get_mod_id(idx),
             lua_manager_get_mod_config_key(idx, cfg_idx),
             lua_manager_get_mod_config_value_str(idx, cfg_idx));
    console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
}

static void console_trigger_mod_config_action(const char* id, const char* key) {
    int idx;
    int cfg_idx;
    int type;
    char out[CONSOLE_LINE_TEXT];
    if (!id || !id[0] || !key || !key[0]) {
        console_push_line_rgb("Usage: mods.config.action <id> <key>", 0.98f, 0.76f, 0.40f);
        return;
    }
    idx = console_find_mod_index_by_id(id);
    if (idx < 0) {
        snprintf(out, sizeof(out), "Mod not found: %s", id);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
        return;
    }
    cfg_idx = console_find_cfg_index_by_key(idx, key);
    if (cfg_idx < 0) {
        snprintf(out, sizeof(out), "Config key not found: %s", key);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
        return;
    }

    type = lua_manager_get_mod_config_type(idx, cfg_idx);
    if (type != LUA_CFG_ACTION) {
        console_push_line_rgb("Config key is not an action.", 0.98f, 0.76f, 0.40f);
        return;
    }

    lua_manager_config_trigger_action(idx, cfg_idx);
    snprintf(out, sizeof(out), "Triggered action: %s.%s", lua_manager_get_mod_id(idx), key);
    console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
}

static void console_run_reload_mods(void) {
    int ok = lua_manager_reload_mods();
    if (ok) console_push_line_rgb("reload.mods: success", 0.64f, 0.92f, 0.66f);
    else console_push_line_rgb("reload.mods: failed (see modframework.log)", 0.98f, 0.45f, 0.45f);
}

static void console_run_reload_assets(void) {
    int tex_reloaded = 0;
    int tex_failed = 0;
    int tex_restart = 0;
    int font_reloaded = 0;
    int font_failed = 0;
    int font_restart = 0;
    int ok = lua_manager_reload_assets(
        &tex_reloaded, &tex_failed, &tex_restart,
        &font_reloaded, &font_failed, &font_restart
    );

    {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out),
                 "reload.assets: ok=%s tex=%d fail=%d restart=%d font=%d fail=%d restart=%d",
                 ok ? "true" : "false",
                 tex_reloaded, tex_failed, tex_restart,
                 font_reloaded, font_failed, font_restart);
        console_push_line_rgb(out, ok ? 0.64f : 0.98f, ok ? 0.92f : 0.45f, ok ? 0.66f : 0.45f);
    }
}

static void console_set_log_level(const char* level_arg) {
    char out[CONSOLE_LINE_TEXT];
    if (!level_arg || !level_arg[0]) {
        snprintf(out, sizeof(out), "log.level is %s", log_get_level_name());
        console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
        return;
    }

    if (!log_set_level_name(level_arg)) {
        console_push_line_rgb("Usage: log.level <debug|info|warn|error>", 0.98f, 0.76f, 0.40f);
        return;
    }

    snprintf(out, sizeof(out), "log.level set to %s", log_get_level_name());
    console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
}

static void console_handle_time_scale(const char* arg) {
    char out[CONSOLE_LINE_TEXT];
    int manual_active = lua_manager_get_time_scale_manual(NULL);

    if (!arg || !arg[0]) {
        snprintf(out, sizeof(out), "time.scale: %.6g%s",
                 (double)lua_manager_get_time_scale(),
                 manual_active ? " (manual)" : "");
        console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
        return;
    }

    {
        char arg_buf[CONSOLE_INPUT_BUF];
        char* a;
        double value = 1.0;
        safe_copy(arg_buf, sizeof(arg_buf), arg);
        a = trim_ws(arg_buf);
        if (!a || !a[0]) {
            snprintf(out, sizeof(out), "time.scale: %.6g%s",
                     (double)lua_manager_get_time_scale(),
                     manual_active ? " (manual)" : "");
            console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
            return;
        }

        if (_stricmp(a, "auto") == 0 || _stricmp(a, "default") == 0) {
            lua_manager_clear_time_scale();
            snprintf(out, sizeof(out), "time.scale manual override cleared (current %.6g)",
                     (double)lua_manager_get_time_scale());
            console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
            return;
        }

        if (!console_try_parse_double(a, &value)) {
            console_push_line_rgb("Usage: time.scale [value|auto]", 0.98f, 0.76f, 0.40f);
            return;
        }

        lua_manager_set_time_scale((float)value);
        snprintf(out, sizeof(out), "time.scale set to %.6g",
                 (double)lua_manager_get_time_scale());
        console_push_line_rgb(out, 0.64f, 0.92f, 0.66f);
    }
}

static void console_tail_log(const char* lines_arg) {
    const char* path = "mods\\modframework.log";
    FILE* f;
    long want = 30;
    int total = 0;
    int skip = 0;
    char line[1024];
    char out[CONSOLE_LINE_TEXT];

    if (lines_arg && lines_arg[0]) {
        long parsed = 0;
        if (!console_try_parse_long(lines_arg, &parsed) || parsed <= 0) {
            console_push_line_rgb("Usage: log.tail [positive_line_count]", 0.98f, 0.76f, 0.40f);
            return;
        }
        if (parsed > 300) parsed = 300;
        want = parsed;
    }

    f = fopen(path, "r");
    if (!f) {
        console_push_line_rgb("log.tail: failed to open mods/modframework.log", 0.98f, 0.45f, 0.45f);
        return;
    }

    while (fgets(line, sizeof(line), f)) total++;
    if (total > want) skip = total - (int)want;
    rewind(f);
    while (skip > 0 && fgets(line, sizeof(line), f)) skip--;

    snprintf(out, sizeof(out), "log.tail: showing last %d of %d line(s)", total < (int)want ? total : (int)want, total);
    console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);

    while (fgets(line, sizeof(line), f)) {
        console_strip_crlf(line);
        if (!line[0]) continue;
        console_push_line_rgb(line, 0.78f, 0.82f, 0.88f);
    }
    fclose(f);
}

static void console_run_lua_code(const char* code) {
    char out[1024];
    int ok;
    if (!code || !code[0]) {
        console_push_line_rgb("Usage: lua <code>", 0.98f, 0.76f, 0.40f);
        return;
    }
    ok = lua_manager_console_eval(code, out, (int)sizeof(out));
    console_push_line_rgb(out[0] ? out : (ok ? "ok" : "lua error"),
                          ok ? 0.64f : 0.98f,
                          ok ? 0.92f : 0.45f,
                          ok ? 0.66f : 0.45f);
}

static void console_run_lua_mod_code(const char* args) {
    char buf[CONSOLE_INPUT_BUF];
    char* cursor;
    char* mod_id;
    char* code;
    char out[1024];
    int ok;

    if (!args || !args[0]) {
        console_push_line_rgb("Usage: lua.mod <id> <code>", 0.98f, 0.76f, 0.40f);
        return;
    }

    safe_copy(buf, sizeof(buf), args);
    cursor = buf;
    mod_id = console_parse_token(&cursor);
    code = trim_ws(cursor ? cursor : "");
    if (!mod_id || !mod_id[0] || !code || !code[0]) {
        console_push_line_rgb("Usage: lua.mod <id> <code>", 0.98f, 0.76f, 0.40f);
        return;
    }

    ok = lua_manager_console_eval_mod(mod_id, code, out, (int)sizeof(out));
    console_push_line_rgb(out[0] ? out : (ok ? "ok" : "lua error"),
                          ok ? 0.64f : 0.98f,
                          ok ? 0.92f : 0.45f,
                          ok ? 0.66f : 0.45f);
}

static void console_run_lua_file(const char* arg) {
    char buf[CONSOLE_INPUT_BUF];
    char* cursor;
    char* path;
    char out[1024];
    int ok;

    if (!arg || !arg[0]) {
        console_push_line_rgb("Usage: lua.file <path>", 0.98f, 0.76f, 0.40f);
        return;
    }

    safe_copy(buf, sizeof(buf), arg);
    cursor = buf;
    path = console_parse_token(&cursor);
    if (!path || !path[0]) {
        console_push_line_rgb("Usage: lua.file <path>", 0.98f, 0.76f, 0.40f);
        return;
    }

    ok = lua_manager_console_run_file(path, out, (int)sizeof(out));
    console_push_line_rgb(out[0] ? out : (ok ? "ok" : "lua error"),
                          ok ? 0.64f : 0.98f,
                          ok ? 0.92f : 0.45f,
                          ok ? 0.66f : 0.45f);
}

static void console_show_input_override(const char* player_arg) {
    int p0 = 0;
    int p1 = 1;
    if (player_arg && player_arg[0]) {
        long p = 0;
        if (!console_try_parse_long(player_arg, &p) || p < 0 || p > 1) {
            console_push_line_rgb("Usage: input.show [0|1]", 0.98f, 0.76f, 0.40f);
            return;
        }
        p0 = (int)p;
        p1 = (int)p;
    }

    for (int pi = p0; pi <= p1; pi++) {
        uint32_t mask = 0;
        int frames = 0;
        int replace = 0;
        int active = hooks_get_input_override(pi, &mask, &frames, &replace);
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "input[%d]: active=%s mask=0x%08X frames=%d replace=%d",
                 pi, active ? "true" : "false", (unsigned int)mask, frames, replace);
        console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
    }
}

static void console_set_input_override_cmd(const char* args) {
    char buf[CONSOLE_INPUT_BUF];
    char* cursor;
    char* tok_player;
    char* tok_mask;
    char* tok_frames;
    char* tok_replace;
    long p = 0;
    long mask = 0;
    long frames = -1;
    long replace = 0;
    if (!args || !args[0]) {
        console_push_line_rgb("Usage: input.override <player> <mask> [frames] [replace]", 0.98f, 0.76f, 0.40f);
        return;
    }
    safe_copy(buf, sizeof(buf), args);
    cursor = buf;
    tok_player = console_parse_token(&cursor);
    tok_mask = console_parse_token(&cursor);
    tok_frames = console_parse_token(&cursor);
    tok_replace = console_parse_token(&cursor);

    if (!tok_player || !tok_mask) {
        console_push_line_rgb("Usage: input.override <player> <mask> [frames] [replace]", 0.98f, 0.76f, 0.40f);
        return;
    }
    if (!console_try_parse_long(tok_player, &p) || p < 0 || p > 1) {
        console_push_line_rgb("input.override: player must be 0 or 1", 0.98f, 0.76f, 0.40f);
        return;
    }
    if (!console_try_parse_long(tok_mask, &mask)) {
        console_push_line_rgb("input.override: mask must be an integer (decimal or hex)", 0.98f, 0.76f, 0.40f);
        return;
    }
    if (tok_frames && tok_frames[0]) {
        if (!console_try_parse_long(tok_frames, &frames)) {
            console_push_line_rgb("input.override: frames must be an integer", 0.98f, 0.76f, 0.40f);
            return;
        }
    }
    if (tok_replace && tok_replace[0]) {
        if (!console_try_parse_long(tok_replace, &replace)) {
            console_push_line_rgb("input.override: replace must be 0 or 1", 0.98f, 0.76f, 0.40f);
            return;
        }
        replace = replace ? 1 : 0;
    }

    hooks_set_input_override((int)p, (uint32_t)mask, (int)frames, (int)replace);
    console_show_input_override(tok_player);
}

static void console_clear_input_override_cmd(const char* player_arg) {
    long p = 0;
    if (!player_arg || !player_arg[0]) {
        console_push_line_rgb("Usage: input.clear <player>", 0.98f, 0.76f, 0.40f);
        return;
    }
    if (!console_try_parse_long(player_arg, &p) || p < 0 || p > 1) {
        console_push_line_rgb("input.clear: player must be 0 or 1", 0.98f, 0.76f, 0.40f);
        return;
    }
    hooks_clear_input_override((int)p);
    console_show_input_override(player_arg);
}

static void console_execute_input(void) {
    char work[CONSOLE_INPUT_BUF];
    char* cmd;
    char* arg = NULL;
    char* p;

    safe_copy(work, sizeof(work), g_console_input);
    cmd = trim_ws(work);
    if (!cmd || !cmd[0]) {
        console_set_input("");
        console_reset_history_nav();
        return;
    }

    console_push_command_line(cmd);
    console_history_add(cmd);
    console_reset_history_nav();

    p = cmd;
    while (*p && !isspace((unsigned char)*p)) p++;
    if (*p) {
        *p = '\0';
        p++;
        arg = trim_ws(p);
    } else {
        arg = "";
    }

    if (_stricmp(cmd, "help") == 0 || _stricmp(cmd, "commands") == 0) {
        console_show_help(arg);
    } else if (_stricmp(cmd, "clear") == 0) {
        console_clear_output();
    } else if (_stricmp(cmd, "history") == 0) {
        console_show_history(arg);
    } else if (_stricmp(cmd, "echo") == 0) {
        console_echo(arg);
    } else if (_stricmp(cmd, "console.stats") == 0) {
        console_show_console_stats();
    } else if (_stricmp(cmd, "state") == 0) {
        console_show_state();
    } else if (_stricmp(cmd, "state.last") == 0) {
        console_show_last_state();
    } else if (_stricmp(cmd, "state.return") == 0) {
        console_set_return_state(arg);
    } else if (_stricmp(cmd, "state.switch") == 0) {
        console_switch_state(arg);
    } else if (_stricmp(cmd, "sys.info") == 0) {
        console_show_system_info();
    } else if (_stricmp(cmd, "ui.size") == 0) {
        console_show_ui_size();
    } else if (_stricmp(cmd, "time.scale") == 0) {
        console_handle_time_scale(arg);
    } else if (_stricmp(cmd, "framework.api") == 0) {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "framework.api: %d", lua_manager_framework_api());
        console_push_line_rgb(out, 0.72f, 0.90f, 1.00f);
    } else if (_stricmp(cmd, "mods.count") == 0) {
        console_show_mods_count();
    } else if (_stricmp(cmd, "mods.list") == 0) {
        console_show_mods_list();
    } else if (_stricmp(cmd, "mods.find") == 0) {
        console_find_mods(arg);
    } else if (_stricmp(cmd, "mods.info") == 0) {
        console_show_mod_info(arg);
    } else if (_stricmp(cmd, "mods.enable") == 0) {
        console_set_mod_enabled(arg, 1);
    } else if (_stricmp(cmd, "mods.disable") == 0) {
        console_set_mod_enabled(arg, 0);
    } else if (_stricmp(cmd, "mods.toggle") == 0) {
        console_toggle_mod_enabled(arg);
    } else if (_stricmp(cmd, "mods.config") == 0 || _stricmp(cmd, "mods.cfg") == 0) {
        console_show_mod_config(arg);
    } else if (_stricmp(cmd, "mods.config.find") == 0 || _stricmp(cmd, "mods.cfg.find") == 0) {
        console_find_mod_config(arg);
    } else if (_stricmp(cmd, "mods.config.get") == 0 || _stricmp(cmd, "mods.cfg.get") == 0) {
        char args_buf[CONSOLE_INPUT_BUF];
        char* cursor;
        char* id;
        char* key;
        safe_copy(args_buf, sizeof(args_buf), arg);
        cursor = args_buf;
        id = console_parse_token(&cursor);
        key = console_parse_token(&cursor);
        console_show_mod_config_value(id ? id : "", key ? key : "");
    } else if (_stricmp(cmd, "mods.config.set") == 0 || _stricmp(cmd, "mods.cfg.set") == 0) {
        char args_buf[CONSOLE_INPUT_BUF];
        char* cursor;
        char* id;
        char* key;
        char* value;
        safe_copy(args_buf, sizeof(args_buf), arg);
        cursor = args_buf;
        id = console_parse_token(&cursor);
        key = console_parse_token(&cursor);
        value = cursor ? trim_ws(cursor) : "";
        if (value && value[0] && (value[0] == '"' || value[0] == '\'')) {
            char q = value[0];
            size_t len;
            value++;
            len = strlen(value);
            if (len > 0 && value[len - 1] == q) value[len - 1] = '\0';
        }
        console_set_mod_config_value(id ? id : "", key ? key : "", value ? value : "");
    } else if (_stricmp(cmd, "mods.config.action") == 0 || _stricmp(cmd, "mods.cfg.action") == 0) {
        char args_buf[CONSOLE_INPUT_BUF];
        char* cursor;
        char* id;
        char* key;
        safe_copy(args_buf, sizeof(args_buf), arg);
        cursor = args_buf;
        id = console_parse_token(&cursor);
        key = console_parse_token(&cursor);
        console_trigger_mod_config_action(id ? id : "", key ? key : "");
    } else if (_stricmp(cmd, "reload.mods") == 0) {
        console_run_reload_mods();
    } else if (_stricmp(cmd, "mods.reload") == 0) {
        console_run_reload_mods();
    } else if (_stricmp(cmd, "reload.assets") == 0) {
        console_run_reload_assets();
    } else if (_stricmp(cmd, "log.level") == 0) {
        console_set_log_level(arg);
    } else if (_stricmp(cmd, "log.tail") == 0) {
        console_tail_log(arg);
    } else if (_stricmp(cmd, "input.show") == 0) {
        console_show_input_override(arg);
    } else if (_stricmp(cmd, "input.override") == 0) {
        console_set_input_override_cmd(arg);
    } else if (_stricmp(cmd, "input.clear") == 0) {
        console_clear_input_override_cmd(arg);
    } else if (_stricmp(cmd, "lua") == 0 || _stricmp(cmd, "eval") == 0) {
        console_run_lua_code(arg);
    } else if (_stricmp(cmd, "lua.mod") == 0 || _stricmp(cmd, "eval.mod") == 0) {
        console_run_lua_mod_code(arg);
    } else if (_stricmp(cmd, "lua.file") == 0) {
        console_run_lua_file(arg);
    } else if (_stricmp(cmd, "exit") == 0) {
        console_close();
    } else if (_stricmp(cmd, "quit") == 0) {
        console_close();
    } else {
        char out[CONSOLE_LINE_TEXT];
        snprintf(out, sizeof(out), "Unknown command: %s (type 'help')", cmd);
        console_push_line_rgb(out, 0.98f, 0.45f, 0.45f);
    }

    console_set_input("");
}

static char keycode_to_char(int sym, int mod) {
    int shift = (mod & KMOD_SHIFT) != 0;

    if (sym >= 'a' && sym <= 'z') {
        return (char)(shift ? toupper(sym) : sym);
    }

    if (sym >= '0' && sym <= '9') {
        if (!shift) return (char)sym;
        switch (sym) {
            case '1': return '!';
            case '2': return '@';
            case '3': return '#';
            case '4': return '$';
            case '5': return '%';
            case '6': return '^';
            case '7': return '&';
            case '8': return '*';
            case '9': return '(';
            case '0': return ')';
        }
    }

    switch (sym) {
        case SDLK_SPACE: return ' ';
        case '-': return shift ? '_' : '-';
        case '=': return shift ? '+' : '=';
        case '[': return shift ? '{' : '[';
        case ']': return shift ? '}' : ']';
        case '\\': return shift ? '|' : '\\';
        case ';': return shift ? ':' : ';';
        case '\'': return shift ? '"' : '\'';
        case ',': return shift ? '<' : ',';
        case '.': return shift ? '>' : '.';
        case '/': return shift ? '?' : '/';
        case '`': return shift ? '~' : '`';
        default: return 0;
    }
}

int hooks_console_active(void) {
    return is_console_state_active();
}

void hooks_console_on_pre_swap(void) {
    if (!g_console_open_pending) return;

    g_console_bg_ready = 0;
    g_console_bg_w = 0;
    g_console_bg_h = 0;
    (void)console_capture_background_now();

    g_console_open_pending = 0;
    g_console_open_ready = 1;
}

void hooks_console_pump(void) {
    if (!g_console_open_ready) return;
    g_console_open_ready = 0;
    g_console_return_state = g_console_pending_return_state;
    if (!g_console_return_state || g_console_return_state == (void*)&g_console_state) {
        g_console_return_state = (void*)(uintptr_t)ADDR_MAIN_STATE;
    }
    if (p_state_switch && !is_console_state_active()) {
        p_state_switch((void*)&g_console_state);
    }
}

int hooks_console_textinput(const char* text) {
    if (g_console_suppress_next_textinput > 0) {
        g_console_suppress_next_textinput--;
        return 1;
    }
    if (!is_console_state_active()) return 0;
    if (text && text[0]) {
        console_insert_text(text);
    }
    return 1;
}

int hooks_console_control_action(int action) {
    if (!is_console_state_active()) return 0;
    switch (action) {
        case 1: console_history_step(-1); return 1;
        case 2: console_history_step(1);  return 1;
        case 3:
            if (g_console_cursor > 0) g_console_cursor--;
            return 1;
        case 4:
            if ((size_t)g_console_cursor < strlen(g_console_input)) g_console_cursor++;
            return 1;
        case 5: console_execute_input(); return 1;
        case 6: console_close(); return 1;
        default: return 1;
    }
}

int hooks_console_keydown(int sym, int scancode, int mod) {
    (void)scancode;

    if (sym == '`') {
        g_console_suppress_next_textinput = 1;
        if (is_console_state_active()) {
            console_close();
        } else if (g_console_open_pending || g_console_open_ready) {
            g_console_open_pending = 0;
            g_console_open_ready = 0;
        } else {
            console_open();
        }
        return 1;
    }

    if (!is_console_state_active()) return 0;

    switch (sym) {
        case SDLK_ESCAPE:
            console_close();
            return 1;
        case SDLK_RETURN:
        case SDLK_KP_ENTER:
            console_execute_input();
            return 1;
        case SDLK_BACKSPACE:
            console_backspace();
            return 1;
        case SDLK_DELETE:
            console_delete();
            return 1;
        case SDLK_LEFT:
            if (g_console_cursor > 0) g_console_cursor--;
            return 1;
        case SDLK_RIGHT:
            if ((size_t)g_console_cursor < strlen(g_console_input)) g_console_cursor++;
            return 1;
        case SDLK_HOME:
            g_console_cursor = 0;
            return 1;
        case SDLK_END:
            g_console_cursor = (int)strlen(g_console_input);
            return 1;
        case SDLK_UP:
            console_history_step(-1);
            return 1;
        case SDLK_DOWN:
            console_history_step(1);
            return 1;
        case SDLK_PAGEUP:
            console_scroll_by(8);
            return 1;
        case SDLK_PAGEDOWN:
            console_scroll_by(-8);
            return 1;
        case 'l':
        case 'L':
            if (mod & KMOD_CTRL) {
                console_clear_output();
                return 1;
            }
            return 1;
        default:
            return 1;
    }
}

int hooks_text_capture_active(void) {
    return g_capture_active;
}

int hooks_mods_menu_active(void) {
    return is_mods_state_active();
}

void hooks_mods_menu_notify_reload(void) {
    g_capture_active = 0;
    g_capture_mod = -1;
    g_capture_cfg = -1;

    if (is_mods_state_active()) {
        rebuild_rows();
        mods_cursor_tick();
    }
}

int hooks_text_capture_keydown(int sym, int scancode, int mod) {
    (void)scancode;

    if (!g_capture_active) return 0;
    if (!is_mods_state_active()) {
        g_capture_active = 0;
        return 0;
    }

    if (sym == SDLK_ESCAPE) {
        g_capture_active = 0;
        g_capture_mod = -1;
        g_capture_cfg = -1;
        return 1;
    }

    if (sym == SDLK_RETURN || sym == SDLK_KP_ENTER) {
        lua_manager_config_set_string(g_capture_mod, g_capture_cfg, g_capture_buf);
        g_capture_active = 0;
        g_capture_mod = -1;
        g_capture_cfg = -1;
        rebuild_rows();
        return 1;
    }

    if (sym == SDLK_BACKSPACE) {
        size_t len = strlen(g_capture_buf);
        if (len > 0) g_capture_buf[len - 1] = '\0';
        return 1;
    }

    if (sym == SDLK_DELETE) {
        g_capture_buf[0] = '\0';
        return 1;
    }

    {
        char c = keycode_to_char(sym, mod);
        if (c) {
            size_t len = strlen(g_capture_buf);
            if (len + 1 < sizeof(g_capture_buf)) {
                g_capture_buf[len] = c;
                g_capture_buf[len + 1] = '\0';
            }
            return 1;
        }
    }

    return 1;
}

int hooks_mods_menu_keydown(int sym, int scancode, int mod) {
    (void)scancode;
    (void)mod;

    if (!is_mods_state_active()) return 0;
    if (g_capture_active) return 1;

    rebuild_rows();

    switch (sym) {
        case SDLK_ESCAPE:
            mods_go_back();
            return 1;

        case SDLK_UP:
        case 'w':
        case 'W':
            move_selection(-1, 1);
            return 1;

        case SDLK_DOWN:
        case 's':
        case 'S':
            move_selection(1, 1);
            return 1;

        case SDLK_PAGEUP: {
            int step = visible_rows_capacity() - 2;
            if (step < 1) step = 1;
            move_selection(-1, step);
            return 1;
        }

        case SDLK_PAGEDOWN: {
            int step = visible_rows_capacity() - 2;
            if (step < 1) step = 1;
            move_selection(1, step);
            return 1;
        }

        case SDLK_HOME: {
            int prev = g_selected_row;
            int first = first_selectable_index();
            if (first >= 0) g_selected_row = first;
            ensure_scroll_visible();
            if (g_selected_row != prev) mods_cursor_on_selection_changed();
            return 1;
        }

        case SDLK_END: {
            int prev = g_selected_row;
            int last = last_selectable_index();
            if (last >= 0) g_selected_row = last;
            ensure_scroll_visible();
            if (g_selected_row != prev) mods_cursor_on_selection_changed();
            return 1;
        }

        case SDLK_LEFT:
        case 'a':
        case 'A':
            apply_adjustment_on_selected(-1);
            return 1;

        case SDLK_RIGHT:
        case 'd':
        case 'D':
            apply_adjustment_on_selected(1);
            return 1;

        case SDLK_RETURN:
        case SDLK_KP_ENTER:
        case SDLK_SPACE:
        case 'z': case 'Z':
        case 'x': case 'X':
        case 'c': case 'C':
        case 'v': case 'V':
        case 'f': case 'F':
        case 'g': case 'G':
        case 'h': case 'H':
        case 'j': case 'J':
        case 'k': case 'K':
        case 'l': case 'L':
        case ';':
        case ',':
        case '.':
        case '/':
            activate_selected();
            return 1;

        default:
            return 0;
    }
}

int hooks_mods_menu_control_action(int action) {
    if (!is_mods_state_active()) return 0;
    if (g_capture_active) return 1;

    rebuild_rows();

    switch (action) {
        case 1: move_selection(-1, 1); return 1;
        case 2: move_selection(1, 1); return 1;
        case 3: apply_adjustment_on_selected(-1); return 1;
        case 4: apply_adjustment_on_selected(1); return 1;
        case 5: activate_selected(); return 1;
        case 6: mods_go_back(); return 1;
        default: return 0;
    }
}

void hooks_set_input_override(int player_index, uint32_t cmd_mask, int frames, int replace) {
    int pi = (player_index & 1);
    if (frames == 0) {
        g_input_override_mask[pi] = 0;
        g_input_override_frames[pi] = 0;
        g_input_override_replace[pi] = 0;
        return;
    }
    g_input_override_mask[pi] = cmd_mask;
    g_input_override_frames[pi] = frames;
    g_input_override_replace[pi] = replace ? 1 : 0;
}

void hooks_clear_input_override(int player_index) {
    int pi = (player_index & 1);
    g_input_override_mask[pi] = 0;
    g_input_override_frames[pi] = 0;
    g_input_override_replace[pi] = 0;
}

int hooks_get_input_override(int player_index, uint32_t* out_mask, int* out_frames, int* out_replace) {
    int pi = (player_index & 1);
    int frames = g_input_override_frames[pi];
    if (out_mask) *out_mask = g_input_override_mask[pi];
    if (out_frames) *out_frames = frames;
    if (out_replace) *out_replace = g_input_override_replace[pi];
    return frames != 0;
}

static void render_rows(void) {
    rebuild_rows();

    ModsLayout L;
    mods_calc_layout(&L);
    g_ui_scale = L.text_scale;

    float ui = L.ui;

    // Header + help: center to the *content* region, and position them relative
    // to list_top so it scales with window height.
    float header_cx = (L.left + L.right) * 0.5f;
    float header_y = L.list_top - (70.0f * ui);
    float help_y   = L.list_top - (44.0f * ui);
    if (header_y < 18.0f * ui) header_y = 18.0f * ui;
    if (help_y   < 42.0f * ui) help_y   = 42.0f * ui;

    draw_text_centered_scaled(header_cx, header_y, g_ui_scale * 1.34f,
                              0.95f, 0.95f, 0.95f, "MOD OPTIONS");

    if (g_capture_active) {
        draw_text_centered_scaled(header_cx, help_y, g_ui_scale * 1.00f,
                                  1.00f, 0.85f, 0.35f,
                                  "Editing text (Enter = apply, Esc = cancel)");
    } else {
        draw_text_centered_scaled(header_cx, help_y, g_ui_scale * 0.92f,
                                  0.60f, 0.70f, 0.82f,
                                  "Up/Down to navigate, Enter to toggle/run, Left/Right to adjust, Esc to go back");
    }

    int cap = visible_rows_capacity();
    int start = g_scroll_row;
    if (start < 0) start = 0;
    if (start > g_row_count) start = g_row_count;

    int end = start + cap;
    if (end > g_row_count) end = g_row_count;

    // Dynamic divider string sized to our content width.
    char divider[256];
    {
        float scale = g_ui_scale * 0.86f;
        int count = (int)((L.content_w - (28.0f * ui)) / (4.2f * scale));
        if (count < 8) count = 8;
        if (count > (int)sizeof(divider) - 1) count = (int)sizeof(divider) - 1;
        build_repeat(divider, sizeof(divider), '-', count);
    }

    for (int i = start; i < end; i++) {
        float y = L.list_top + (float)(i - start) * L.row_h;
        MenuRow* row = &g_rows[i];
        int selected = (i == g_selected_row);

        // Spacer rows (blank info rows) - keep them as vertical padding only.
        if (row->kind == ROW_INFO && row->left[0] == '\0' && row->right[0] == '\0') {
            continue;
        }

        // Palette
        float base_r = 0.92f, base_g = 0.92f, base_b = 0.92f;
        float dim_r  = 0.58f, dim_g  = 0.66f, dim_b  = 0.76f;
        float acc_r  = 1.00f, acc_g  = 0.85f, acc_b  = 0.35f;

        switch (row->kind) {
            case ROW_MOD_HEADER: {
                float name_scale = g_ui_scale * 1.22f;
                float ver_scale  = g_ui_scale * 0.98f;

                draw_text_scaled(L.left + (26.0f * ui), y, name_scale,
                                 0.80f, 0.86f, 0.94f,
                                 row->left);

                if (row->right[0]) {
                    draw_text_right_scaled(L.right - (16.0f * ui), y, ver_scale,
                                           dim_r, dim_g, dim_b,
                                           row->right);
                }
                // (no ASCII underline; spacing comes from divider rows)
            } break;

            case ROW_DIVIDER: {
                // Pure spacing row (no ASCII divider)
            } break;

            case ROW_CONFIG: {
                float label_x = L.label_x + (18.0f * ui);
                float right_x = L.right - (16.0f * ui);

                // Label
                if (selected) {
                    draw_text_scaled(label_x, y, g_ui_scale * 1.08f, acc_r, acc_g, acc_b, row->left);
                } else {
                    draw_text_scaled(label_x, y, g_ui_scale * 1.08f, base_r, base_g, base_b, row->left);
                }

                // Value (right aligned)
                float vr = dim_r, vg = dim_g, vb = dim_b;
                int type = lua_manager_get_mod_config_type(row->mod_index, row->cfg_index);

                if (type == LUA_CFG_BOOL) {
                    if (row->right[0] == 'O' && row->right[1] == 'N') { vr = 0.45f; vg = 0.92f; vb = 0.55f; }
                    else { vr = 0.95f; vg = 0.45f; vb = 0.45f; }
                } else if (type == LUA_CFG_ACTION) {
                    vr = 0.78f; vg = 0.84f; vb = 0.95f;
                }

                // If we're capturing text on this row, show live buffer with a caret.
                if (g_capture_active &&
                    row->mod_index == g_capture_mod &&
                    row->cfg_index == g_capture_cfg &&
                    type == LUA_CFG_STRING)
                {
                    char live[CAPTURE_BUF_SIZE + 8];
                    snprintf(live, sizeof(live), "\"%s|\"", g_capture_buf);
                    draw_text_right_scaled(right_x, y, g_ui_scale * 1.00f,
                                           selected ? acc_r : vr,
                                           selected ? acc_g : vg,
                                           selected ? acc_b : vb,
                                           live);
                } else {
                    draw_text_right_scaled(right_x, y, g_ui_scale * 1.00f,
                                           selected ? acc_r : vr,
                                           selected ? acc_g : vg,
                                           selected ? acc_b : vb,
                                           row->right);
                }
            } break;

            case ROW_BACK: {
                float back_scale = g_ui_scale * 1.12f;
                draw_text_centered_scaled(L.center_x, y, back_scale,
                                          selected ? acc_r : base_r,
                                          selected ? acc_g : base_g,
                                          selected ? acc_b : base_b,
                                          row->left);
            } break;

            case ROW_INFO: {
                draw_text_centered_scaled(L.center_x, y, g_ui_scale * 0.96f,
                                          dim_r, dim_g, dim_b,
                                          row->left);
            } break;

            default:
                break;
        }
    }

    // Scroll affordances (subtle)
    if (g_scroll_row > 0) {
        draw_text_right_scaled(L.right - (16.0f * ui), L.list_top - (10.0f * ui),
                               g_ui_scale * 0.96f,
                               0.55f, 0.64f, 0.74f, "^");
    }
    if (g_scroll_row + cap < g_row_count) {
        draw_text_right_scaled(L.right - (16.0f * ui), L.list_bottom - (10.0f * ui),
                               g_ui_scale * 0.96f,
                               0.55f, 0.64f, 0.74f, "v");
    }

    // Position indicator
    if (g_row_count > 0 && g_selected_row >= 0) {
        char pos[64];
        snprintf(pos, sizeof(pos), "%d/%d", g_selected_row + 1, g_row_count);
        draw_text_right_scaled(L.right - (16.0f * ui), 44.0f * ui,
                               g_ui_scale * 0.82f,
                               0.46f, 0.54f, 0.64f, pos);
    }

    mods_restore_render_state();
}

static void console_draw_rect(float x, float y, float w, float h, float r, float g, float b, float a) {
    glColor4f(r, g, b, a);
    glBegin(GL_QUADS);
    glVertex2f(x, y);
    glVertex2f(x + w, y);
    glVertex2f(x + w, y + h);
    glVertex2f(x, y + h);
    glEnd();
}

static void console_draw_background(float w, float h) {
    GLint prev_matrix_mode = GL_MODELVIEW;
    glGetIntegerv(GL_MATRIX_MODE, &prev_matrix_mode);

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(0.0, (double)w, (double)h, 0.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glMatrixMode(GL_TEXTURE);
    glPushMatrix();
    glLoadIdentity();

    if (g_console_bg_ready && g_console_bg_tex != 0 && g_console_bg_w > 0 && g_console_bg_h > 0) {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, g_console_bg_tex);
        glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
        glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        glBegin(GL_QUADS);
        glTexCoord2f(0.0f, 1.0f); glVertex2f(0.0f, 0.0f);
        glTexCoord2f(1.0f, 1.0f); glVertex2f(w, 0.0f);
        glTexCoord2f(1.0f, 0.0f); glVertex2f(w, h);
        glTexCoord2f(0.0f, 0.0f); glVertex2f(0.0f, h);
        glEnd();
    } else {
        glDisable(GL_TEXTURE_2D);
        console_draw_rect(0.0f, 0.0f, w, h, 0.05f, 0.06f, 0.08f, 1.0f);
    }

    glDisable(GL_TEXTURE_2D);
    console_draw_rect(0.0f, 0.0f, w, h, 0.02f, 0.03f, 0.04f, 0.24f);

    glMatrixMode(GL_TEXTURE);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(prev_matrix_mode);
    glPopAttrib();
}

static void console_render_ui(void) {
    float w = p_mad_w ? p_mad_w() : BASE_UI_W;
    float h = p_mad_h ? p_mad_h() : BASE_UI_H;
    float ui = calc_ui_scale();
    float panel_x = 36.0f * ui;
    float panel_w = w - (72.0f * ui);
    float panel_h = h * 0.50f;
    float panel_y;
    float title_scale;
    float text_scale;
    float line_h;
    float lines_top;
    float input_y;
    int visible_lines;
    int newest;
    int first;
    int line_no;
    int text_q;

    if (panel_w < 320.0f) panel_w = 320.0f;
    // Give taller consoles on larger windows while keeping safe margins.
    if (h >= 860.0f) panel_h = h * 0.58f;
    if (h >= 1080.0f) panel_h = h * 0.62f;
    if (panel_h > h - (82.0f * ui)) panel_h = h - (82.0f * ui);
    if (panel_h < 220.0f) panel_h = 220.0f;
    panel_y = h - panel_h - (26.0f * ui);
    if (panel_y < 20.0f * ui) panel_y = 20.0f * ui;

    GLint prev_matrix_mode = GL_MODELVIEW;
    glGetIntegerv(GL_MATRIX_MODE, &prev_matrix_mode);

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_TEXTURE_2D);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(0.0, (double)w, (double)h, 0.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    console_draw_rect(panel_x, panel_y, panel_w, panel_h, 0.03f, 0.05f, 0.08f, 0.82f);
    console_draw_rect(panel_x, panel_y, panel_w, 32.0f * ui, 0.07f, 0.11f, 0.18f, 0.92f);
    console_draw_rect(panel_x, panel_y + panel_h - (42.0f * ui), panel_w, 42.0f * ui, 0.02f, 0.04f, 0.06f, 0.92f);
    glColor4f(0.35f, 0.42f, 0.56f, 0.9f);
    glBegin(GL_LINE_LOOP);
    glVertex2f(panel_x, panel_y);
    glVertex2f(panel_x + panel_w, panel_y);
    glVertex2f(panel_x + panel_w, panel_y + panel_h);
    glVertex2f(panel_x, panel_y + panel_h);
    glEnd();

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(prev_matrix_mode);
    glPopAttrib();

    title_scale = clampf(1.00f * ui, 0.95f, 1.55f);
    text_scale = clampf(0.82f * ui, 0.80f, 1.20f);
    text_q = (int)(text_scale * 4.0f + 0.5f);
    if (text_q < 1) text_q = 1;
    text_scale = (float)text_q / 4.0f;
    title_scale = text_scale * 1.18f;
    line_h = (10.0f * text_scale) + (9.0f * ui);
    lines_top = panel_y + (48.0f * ui);
    input_y = panel_y + panel_h - (27.0f * ui);
    visible_lines = (int)((input_y - lines_top - (8.0f * ui)) / line_h);
    if (visible_lines < 3) visible_lines = 3;

    draw_text_scaled((float)((int)(panel_x + (14.0f * ui) + 0.5f)), (float)((int)(panel_y + (22.0f * ui) + 0.5f)),
                     title_scale, 0.94f, 0.96f, 0.99f, "DEV CONSOLE");
    draw_text_right_scaled((float)((int)(panel_x + panel_w - (14.0f * ui) + 0.5f)), (float)((int)(panel_y + (22.0f * ui) + 0.5f)),
                           text_scale, 0.66f, 0.74f, 0.86f,
                           "Enter=run Esc/`=close Up/Down=history Left/Right=cursor");

    newest = g_console_line_count - 1 - g_console_scroll;
    if (newest >= 0) {
        first = newest - visible_lines + 1;
        if (first < 0) first = 0;
        line_no = 0;
        for (int i = first; i <= newest; i++) {
            ConsoleLine* line = console_line_at_oldest_index(i);
            float y = (float)((int)(lines_top + (line_no * line_h) + 0.5f));
            if (!line) continue;
            draw_text_scaled((float)((int)(panel_x + (14.0f * ui) + 0.5f)), y, text_scale, line->r, line->g, line->b, line->text);
            line_no++;
        }
    } else {
        draw_text_scaled((float)((int)(panel_x + (14.0f * ui) + 0.5f)), (float)((int)(lines_top + 0.5f)), text_scale, 0.62f, 0.70f, 0.82f,
                         "No output yet. Type 'help'.");
    }

    {
        char input_line[CONSOLE_INPUT_BUF + 8];
        size_t in_len = strlen(g_console_input);
        if (g_console_cursor < 0) g_console_cursor = 0;
        if ((size_t)g_console_cursor > in_len) g_console_cursor = (int)in_len;
        snprintf(input_line, sizeof(input_line), "> %.*s|%s",
                 g_console_cursor, g_console_input, g_console_input + g_console_cursor);
        draw_text_scaled((float)((int)(panel_x + (14.0f * ui) + 0.5f)), (float)((int)(input_y + 0.5f)), text_scale,
                         0.95f, 0.88f, 0.40f, input_line);
    }
}

static void __cdecl console_enter(void) {
    g_capture_active = 0;
    g_capture_mod = -1;
    g_capture_cfg = -1;
    g_console_scroll = 0;
    if (g_console_line_count == 0) {
        console_push_line_rgb("Type 'help' for a list of commands.", 0.72f, 0.90f, 1.00f);
    }
}

static void __cdecl console_update(void) {
    // Intentionally no menu-button update path here.
}

static void __cdecl console_render(void) {
    mods_restore_render_state();
    console_draw_background(p_mad_w ? p_mad_w() : BASE_UI_W, p_mad_h ? p_mad_h() : BASE_UI_H);
    console_render_ui();
    mods_restore_render_state();
    if (p_main_sprite_batches_draw) {
        p_main_sprite_batches_draw();
    }
    mods_restore_render_state();
}

static void __cdecl console_leave(void) {
    g_console_open_pending = 0;
    g_console_open_ready = 0;
    g_console_suppress_next_textinput = 0;
}


static void __cdecl mods_enter(void) {
    LOG_INFO("MODS: entering mods menu");
    if (p_main_buttons_start) p_main_buttons_start();

    g_capture_active = 0;
    g_capture_mod = -1;
    g_capture_cfg = -1;

    g_mods_return_state = p_state_last ? p_state_last() : (void*)(uintptr_t)ADDR_OPTIONS_STATE;
    if (!g_mods_return_state || g_mods_return_state == (void*)&g_mods_state) {
        g_mods_return_state = (void*)(uintptr_t)ADDR_OPTIONS_STATE;
    }

    rebuild_rows();
    g_cursor_initialized = 0;
    g_cursor_bump = 0;
    mods_cursor_tick();
}

static void __cdecl mods_update(void) {
    p_main_update_with_buttons(0);
    mods_cursor_tick();
}

static void __cdecl mods_render(void) {
    mods_restore_render_state();
    p_menu_common_render();
    render_rows();
    // Restore turtle defaults before main_draw() so sprite/glow/cursor passes
    // don't inherit text render scale/tint.
    mods_restore_render_state();
    // In base menus, rendering is finalized via main_draw(), which flushes sprite
    // batches and draws particles/cursors/button sprites in the expected order.
    // Call main_draw when available so glow/cursor passes behave exactly like
    // the vanilla menus.
    if (p_main_draw) {
        p_main_draw();
    } else if (p_main_sprite_batches_draw) {
        p_main_sprite_batches_draw();
    }

    mods_restore_render_state();
}

static void __cdecl mods_leave(void) {
    g_capture_active = 0;
    g_capture_mod = -1;
    g_capture_cfg = -1;
    mods_restore_render_state();
}

static void __cdecl mods_entry_enter(void) {
    p_state_switch((void*)&g_mods_state);
}

static void __cdecl mods_entry_update(void) { }
static void __cdecl mods_entry_render(void) { }
static void __cdecl mods_entry_leave(void) { }

static int install_detour(Detour* d, void* target, void* hook, size_t length) {
    if (!d || !target || !hook) return 0;
    if (length < 5 || length > sizeof(d->original)) return 0;

    memset(d, 0, sizeof(*d));
    d->target = target;
    d->length = length;

    memcpy(d->original, target, length);

    d->trampoline = VirtualAlloc(NULL, length + 7, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!d->trampoline) return 0;

    memcpy(d->trampoline, d->original, length);

    {
        uint8_t* jump_back = (uint8_t*)d->trampoline + length;
        uintptr_t back_addr = (uintptr_t)target + length;

        // push back_addr; ret  (absolute jump without clobbering EAX)
        jump_back[0] = 0x68; // push imm32
        *(uint32_t*)(jump_back + 1) = (uint32_t)back_addr;
        jump_back[5] = 0xC3; // ret
        jump_back[6] = 0x90; // nop (padding)
    }

    {
        DWORD old_protect = 0;
        if (!VirtualProtect(target, length, PAGE_EXECUTE_READWRITE, &old_protect)) {
            return 0;
        }

        {
            uint8_t* at = (uint8_t*)target;
            uintptr_t rel = (uintptr_t)hook - ((uintptr_t)target + 5);
            at[0] = 0xE9;
            *(uint32_t*)(at + 1) = (uint32_t)rel;
            for (size_t i = 5; i < length; i++) at[i] = 0x90;
        }

        FlushInstructionCache(GetCurrentProcess(), target, length);
        VirtualProtect(target, length, old_protect, &old_protect);
    }

    return 1;
}

// Old-style link filter: allow either player selector to activate the same button.
static int __cdecl mods_entry_player_filter_proxy(void* btn, int event_code) {
    if (!btn || !p_btn_player_filter) return 0;

    // Direct activation path: consume the activation and open custom MODS now.
    if (event_code == 3) {
        uint32_t* tag_ptr = (uint32_t*)((uint8_t*)btn + 4);
        uint32_t old_tag = *tag_ptr;
        int ok = 0;

        *tag_ptr = 0x11;
        ok = p_btn_player_filter(btn, event_code);
        if (!ok) {
            *tag_ptr = 0x12;
            ok = p_btn_player_filter(btn, event_code);
        }
        *tag_ptr = old_tag;

        if (ok) {
            p_state_switch((void*)&g_mods_state);
        }
        return 0;
    }

    uint32_t* tag_ptr = (uint32_t*)((uint8_t*)btn + 4);
    uint32_t old_tag = *tag_ptr;

    *tag_ptr = 0x11;
    if (p_btn_player_filter(btn, event_code)) {
        *tag_ptr = old_tag;
        return 1;
    }

    *tag_ptr = 0x12;
    if (p_btn_player_filter(btn, event_code)) {
        *tag_ptr = old_tag;
        return 1;
    }

    *tag_ptr = old_tag;
    return 0;
}

static void add_mods_button_to_options(void) {
    if (!p_menu_button_link) return;
    if (p_button_set_layout) {
        // Match old working entry: back-button-like sizing in the top-right lane.
        p_button_set_layout(5.0f, 5.0f);
    }
    {
        // Old placement: above Player 2 Input.
        void* btn = p_menu_button_link(4.0f, -1.05f, "MODS", (void*)&g_mods_entry_state);
        if (btn) {
            // Force bridge target explicitly so legacy paths cannot land in old menu states.
            *(void**)((uint8_t*)btn + 0xE0) = (void*)&g_mods_entry_state;
            // Use old filter path so both selectors can activate it (not just mouse).
            *(void**)((uint8_t*)btn + 0xE4) = (void*)&mods_entry_player_filter_proxy;
        }
    }
}

static void __cdecl hooked_options_enter(void) {
    fn_void_void_t real_enter = p_options_enter_trampoline ? p_options_enter_trampoline : p_options_enter;
    real_enter();
    add_mods_button_to_options();
}

static void __cdecl hooked_options_enter_paused(void) {
    fn_void_void_t real_enter = p_options_enter_paused_trampoline ? p_options_enter_paused_trampoline : p_options_enter_paused;
    real_enter();
    add_mods_button_to_options();
}

static uint32_t __cdecl hooked_main_player_poll_cmds(uint32_t player_index, uint32_t mode) {
    fn_main_player_poll_cmds_t real_poll = p_main_player_poll_cmds_trampoline
        ? p_main_player_poll_cmds_trampoline
        : p_main_player_poll_cmds;

    uint32_t cmd = real_poll ? real_poll(player_index, mode) : 0u;
    int pi = (int)(player_index & 1u);

    {
        int frames = g_input_override_frames[pi];
        if (frames != 0) {
            uint32_t mask = g_input_override_mask[pi];
            if (g_input_override_replace[pi]) cmd = mask;
            else cmd |= mask;

            if (frames > 0) {
                frames--;
                g_input_override_frames[pi] = frames;
                if (frames == 0) {
                    g_input_override_mask[pi] = 0;
                    g_input_override_replace[pi] = 0;
                }
            }
        }
    }

    return cmd;
}


// =============================
//
// counts are left queued at the end of a frame (cross-frame batching).
//
// Logs are rate-limited and written to mods/modframework.log.

// Turtle color globals (float 0..1) used to build vertex colors (see quad_batch).
#define ADDR_TURTLE_R 0x448110u
#define ADDR_TURTLE_G 0x448114u
#define ADDR_TURTLE_B 0x448118u
#define ADDR_TURTLE_A 0x44811Cu

// Query-only enums (guarded so we don't redefine what gl.h/glext.h already provides)

static RgbaImage* __cdecl hooked_rgba_load(const char* path) {
    fn_rgba_load_t real = p_rgba_load_trampoline ? p_rgba_load_trampoline : p_rgba_load;
    RgbaImage* img = real ? real(path) : NULL;
    if (img) {
        font_ext_on_rgba_load(path, img);
        texture_ext_on_rgba_load(path, img);
    }
    return img;
}

static void __cdecl hooked_mapgen_init(void) {
    fn_void_void_t real = p_mapgen_init_trampoline ? p_mapgen_init_trampoline : p_mapgen_init;
    custom_maps_handle_mapgen_init(real);
}


void hooks_init(void) {
    static int done = 0;
    if (done) return;
    done = 1;




    custom_maps_init();

    if (!install_detour(&g_options_enter_detour, (void*)(uintptr_t)ADDR_OPTIONS_ENTER, (void*)&hooked_options_enter, 5)) {
        LOG_ERROR("hooks_init: failed to detour options enter");
        return;
    }
    p_options_enter_trampoline = (fn_void_void_t)g_options_enter_detour.trampoline;

    if (!install_detour(&g_options_enter_paused_detour, (void*)(uintptr_t)ADDR_OPTIONS_ENTER_PAUSED, (void*)&hooked_options_enter_paused, 5)) {
        LOG_ERROR("hooks_init: failed to detour paused options enter");
        return;
    }
    p_options_enter_paused_trampoline = (fn_void_void_t)g_options_enter_paused_detour.trampoline;


    if (!install_detour(&g_main_player_poll_cmds_detour, (void*)(uintptr_t)ADDR_MAIN_PLAYER_POLL_CMDS, (void*)&hooked_main_player_poll_cmds, 5)) {
        LOG_WARN("hooks_init: failed to detour main_player_poll_cmds (input override API disabled)");
    } else {
        p_main_player_poll_cmds_trampoline = (fn_main_player_poll_cmds_t)g_main_player_poll_cmds_detour.trampoline;
    }

    // Detour rgba_load so we can patch data/font8x8.png pixels before it is
    // packed into the engine's glyph atlas.
    // rgba_load has an 8-byte prologue (push ebx; sub esp,0x28; lea ...), so
    // we patch 8 bytes to avoid splitting instructions.
    if (!install_detour(&g_rgba_load_detour, (void*)(uintptr_t)ADDR_RGBA_LOAD, (void*)&hooked_rgba_load, 8)) {
        LOG_ERROR("hooks_init: failed to detour rgba_load (font glyph overlay disabled)");
    } else {
        p_rgba_load_trampoline = (fn_rgba_load_t)g_rgba_load_detour.trampoline;
    }

    // mapgen_init starts with `sub esp, 0x2c` (3 bytes) followed by a 6-byte
    // absolute mov. Patch 9 bytes so the trampoline never returns into a split
    // instruction.
    if (!install_detour(&g_mapgen_init_detour, (void*)(uintptr_t)ADDR_MAPGEN_INIT, (void*)&hooked_mapgen_init, 9)) {
        LOG_ERROR("hooks_init: failed to detour mapgen_init");
        return;
    }
    p_mapgen_init_trampoline = (fn_void_void_t)g_mapgen_init_detour.trampoline;

    



LOG_INFO("hooks_init: custom MODS menu ready");
}
