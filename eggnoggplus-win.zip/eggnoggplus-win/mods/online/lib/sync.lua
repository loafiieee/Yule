-- lib/sync.lua  –  delay-based input synchronisation for online play.
-- Sets the global `sync` table.
--
-- DESIGN
-- ------
-- Both clients run the game engine forward every tick.  Before the engine
-- reads player inputs on tick T, we inject:
--
--   • local player:  the raw input captured DELAY ticks ago (buffered).
--   • remote player: the input we received from the server for tick T,
--     or – if it hasn't arrived yet – the last known remote input
--     (simple last-input prediction; no rollback in this version).
--
-- At 60 fps DELAY=4 ticks ≈ 67 ms.  For connections with RTT < 134 ms the
-- remote input will arrive before we need it and stalls will be rare.
-- For higher-latency connections prediction kicks in; small visual artefacts
-- may appear but the simulation stays mostly consistent.
--
-- Match ticks are counted from zero at the start of each match so that both
-- clients' tick numbering is independent of the wall-clock game tick counter.

sync = sync or {}

local DELAY        = 4        -- input delay in ticks
local VANILLA_MAPS = 5        -- number of built-in maps (indices 0–4)

-- ── State ───────────────────────────────────────────────────────────────────

local active         = false
local local_idx      = 0      -- player index for local player (0 or 1)
local remote_idx     = 1      -- player index for remote player
local game_start_abs = nil    -- absolute tick_count() when game state began
local match_tick     = 0      -- ticks since match started

local local_buf  = {}   -- local_buf[N]  = cmd bits to apply at match tick N
local remote_buf = {}   -- remote_buf[N] = cmd bits received from server for N

local last_remote_cmd = 0     -- last-known remote input (for prediction)
local stall_ticks     = 0     -- consecutive ticks with missing remote input
local total_stalls    = 0     -- for overlay display

local map_selector = nil      -- set by sync.prepare() before match start

-- ── Public API ──────────────────────────────────────────────────────────────

--- Called when match_found is received.
--- role: 0 = local player is P1, 1 = local player is P2
--- sel:  map selector index to write before starting game
function sync.prepare(role, sel)
    local_idx    = role
    remote_idx   = 1 - role
    map_selector = sel
    -- Pre-fill delay window with neutral inputs so ticks 0..DELAY-1 don't stall
    local_buf  = {}
    remote_buf = {}
    for t = 0, DELAY do
        local_buf[t]  = 0
        remote_buf[t] = 0
    end
    last_remote_cmd = 0
    stall_ticks     = 0
    total_stalls    = 0
    active          = false
    game_start_abs  = nil
    match_tick      = 0
    mod.log("[sync] prepared role=" .. role .. " map_sel=" .. tostring(sel))
end

--- Apply the server-provided map selector so both clients load the same level.
--- Call this just before invoking the START button.
function sync.apply_map()
    if map_selector ~= nil then
        if mod.game.set_map_selector then
            mod.game.set_map_selector(map_selector)
            mod.log("[sync] map selector set to " .. map_selector)
        end
    end
end

--- Start the synchronisation.  Called when the game state first becomes active.
function sync.start()
    if active then return end
    game_start_abs = mod.game.tick_count()
    match_tick     = 0
    active         = true
    mod.log("[sync] started at abs_tick=" .. game_start_abs)
end

--- Stop sync (match ended or disconnected).
function sync.stop()
    active = false
    -- Clear any pending input overrides
    if mod and mod.game then
        mod.game.input_clear(0)
        mod.game.input_clear(1)
    end
    mod.log("[sync] stopped.  stalls=" .. total_stalls)
end

function sync.is_active() return active end

--- Feed an incoming remote input message {tick=N, cmd=M} from the server.
function sync.on_remote_input(tick, cmd)
    remote_buf[tick] = cmd
end

--- Called from mod.on_tick() during gameplay.  Injects both players' inputs.
function sync.tick()
    if not active then return end

    local abs_now  = mod.game.tick_count()
    match_tick = abs_now - game_start_abs

    -- ── Capture and buffer LOCAL input for the FUTURE tick ───────────────
    local future = match_tick + DELAY
    local raw    = mod.game.poll_cmds_raw(local_idx)
    local_buf[future] = raw

    -- ── Send local input to server (stamped with the future match tick) ──
    proto.send({ type = "input", tick = future, cmd = raw })

    -- ── Get this tick's inputs ────────────────────────────────────────────
    local lcmd = local_buf[match_tick]  or 0
    local rcmd = remote_buf[match_tick]

    if rcmd == nil then
        -- Remote input hasn't arrived yet – predict last known
        rcmd          = last_remote_cmd
        stall_ticks   = stall_ticks + 1
        total_stalls  = total_stalls + 1
    else
        last_remote_cmd = rcmd
        stall_ticks     = 0
    end

    -- ── Inject both players ───────────────────────────────────────────────
    -- ticks=1 replace=true: override exactly this one tick, then clear.
    mod.game.set_input(local_idx,  lcmd, 1, true)
    mod.game.set_input(remote_idx, rcmd, 1, true)

    -- ── Clean up old entries to avoid the table growing forever ──────────
    local_buf [match_tick - 1] = nil
    remote_buf[match_tick - 1] = nil
end

--- Draw a small HUD overlay while the match is running.
function sync.draw_hud()
    if not active then return end
    local W, _ = mod.ui.screen_size()
    local role_str = (local_idx == 0) and "P1" or "P2"
    local stall_str = stall_ticks > 0
        and ("  WAIT " .. stall_ticks)
        or  ""
    local info = role_str .. "  T+" .. match_tick .. stall_str
    mod.ui.text_at(info, W - 8, 8, 0.75, 1, 1, 0)
end
