-- mods/online/main.lua  –  Eggnogg+ Online Multiplayer mod entry point.

local SERVER_HOST = config.get("server_host", "127.0.0.1")
local SERVER_PORT = config.get("server_port", 7878)

local START_ACTION  = 0x432440
local GAP           = 10.0

-- ── ONLINE button baseline (vs_ai pattern) ───────────────────────────────────

local baseline_captured     = false
local baseline_from_initial = false
local base_x, base_y, base_w, base_h = nil, nil, nil, nil
local was_in_main = false

local function in_main(st)
    return st == "main" or st == "main_initial"
end

local function capture_baseline(st)
    local ptr = mod.ui.find_button_by_action_ptr(START_ACTION)
    if not ptr then return end
    local want = (not baseline_captured) or
                 (baseline_from_initial and st == "main")
    if want then
        local x, y, w, h = mod.ui.button_rect_ptr(ptr)
        if x and y and w and h and w > 20.0 and h > 10.0 then
            base_x, base_y, base_w, base_h = x, y, w, h
            baseline_captured     = true
            baseline_from_initial = (st == "main_initial")
            if st == "main" then baseline_from_initial = false end
        end
    end
end

-- ── Sub-modules ──────────────────────────────────────────────────────────────

mod.dofile("lib/json.lua")
mod.dofile("lib/proto.lua")
mod.dofile("lib/sync.lua")
mod.dofile("lib/hub.lua")

-- ── Lifecycle ────────────────────────────────────────────────────────────────

mod.on_load(function()
    mod.log("Eggnogg+ Online loaded  server=" ..
            SERVER_HOST .. ":" .. tostring(SERVER_PORT))
end)

mod.on_unload(function()
    sync.stop()
    proto.disconnect()
    mod.log("Eggnogg+ Online unloaded")
end)

-- ── Per-frame ────────────────────────────────────────────────────────────────

local last_tick       = 0
local prev_state_name = ""
local match_started   = false

mod.on_frame(function()
    local tc    = mod.game.tick_count()
    local dt    = math.min((tc - last_tick) / 60.0, 0.1)
    last_tick   = tc

    local sname = mod.ui.state_name()

    -- ── ONLINE button on main menu ──────────────────────────────────────────
    if in_main(sname) then
        if not was_in_main then
            baseline_captured     = false
            baseline_from_initial = false
            base_x, base_y, base_w, base_h = nil, nil, nil, nil
        end

        capture_baseline(sname)

        local clicked = mod.ui.native_button("online_open_btn", "ONLINE",
                                             1.0, 4.5, 3.0, 6.0)
        if base_x and base_y and base_w and base_h then
            mod.ui.native_resize("online_open_btn", base_w, base_h)
            mod.ui.native_set_pos("online_open_btn", base_x, base_y + base_h + GAP)
        end

        if clicked then
            hub.open(SERVER_HOST, SERVER_PORT)
        end

    else
        if was_in_main then
            baseline_captured     = false
            baseline_from_initial = false
            base_x, base_y, base_w, base_h = nil, nil, nil, nil
        end
    end

    was_in_main = in_main(sname)

    -- ── Hub draw (only while in the online_hub game state) ─────────────────
    if sname == "online_hub" then
        hub.draw(dt)
    end

    -- ── In-game: drain messages + draw HUD ──────────────────────────────────
    if sync.is_active() then
        proto.update()
        local msg = proto.poll()
        while msg do
            if msg.type == "match_end" then
                sync.stop()
                hub.open()   -- re-enter hub state
            elseif msg.type == "remote_input" then
                sync.on_remote_input(
                    tonumber(msg.tick) or 0,
                    tonumber(msg.cmd)  or 0)
            end
            msg = proto.poll()
        end
        sync.draw_hud()
    end

    -- ── State transition detection ───────────────────────────────────────────
    if sname ~= prev_state_name then
        if sname == "game" and not match_started
                           and hub.get_state() == "in_game" then
            match_started = true
            sync.start()
            mod.log("[main] game started – sync on")
        end
        if sname == "main" and match_started then
            match_started = false
            if sync.is_active() then
                proto.send({ type = "match_end" })
                sync.stop()
            end
            hub.open()
        end
        prev_state_name = sname
    end
end)

-- ── Per-tick ─────────────────────────────────────────────────────────────────

mod.on_tick(function()
    if sync.is_active() then
        sync.tick()
    end
end)

-- ── Events ───────────────────────────────────────────────────────────────────

mod.on_event(function(e)
    if mod.ui.state_name() == "online_hub" then
        return hub.on_event(e)
    end
    return false
end)
