# VS AI training workflow

This mod does not train in-game yet.

What it does today:
- plays with the current heuristic bot
- records decisions to `mods/vs ai/training_log.tsv` when `log_training=true`

## Collect data from your play

1. Open Mods -> VS AI.
2. Set `ai_level=3` to start.
3. Set `log_training=true`.
4. Click `Clear training log` once before a new session.
5. Play 20 to 50 matches against the bot.
6. Turn `log_training=false` when done.
7. Keep the resulting `training_log.tsv` file.

## What to collect

Do separate sessions for each target style.

### Level 1-2
Let the bot stay weak. Record your own calm, simple play and basic sword pickup behavior.
Goal: teach movement, lane holding, and not panicking.

### Level 3
This is the main baseline.
Record your normal competent play:
- pick swords up quickly
- do not spam jump
- when unarmed against a sword, disengage and re-arm
- when you have GO, leave the room instead of farming hits

### Level 4-5
Record stronger play.
Focus on:
- lane conditioning
- punishing repeated guards
- sword denial
- controlled throws only when recovery is realistic

### Pain Kink Mode
Do not train this separately first.
Get the normal bots working, then fine-tune the strongest checkpoint with:
- zero reaction delay
- no exploration noise
- strongest reward for winning and sword denial
- optional short-horizon search on top of the policy

## First real trainer plan

1. Convert `training_log.tsv` into tensors.
2. Train a behavior-cloning policy first.
3. Put that policy back in the game for inference.
4. Play against it and collect more logs.
5. Then move to self-play PPO using the cloned policy as the starting point.

## Recommended order

1. Get a decent level-3 bot.
2. Clone your play into a first model.
3. Tune runtime handicaps to make levels 1, 2, 4, and 5.
4. Only after that, build self-play and pain kink mode.
