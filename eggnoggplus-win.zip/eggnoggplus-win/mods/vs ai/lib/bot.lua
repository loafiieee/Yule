local C = mod.dofile("lib/constants.lua")
local U = mod.dofile("lib/util.lua")
local O = mod.dofile("lib/observe.lua")
local K = mod.dofile("lib/controller.lua")
local L = mod.dofile("lib/logger.lua")

local M = {}

local function get_profile()
    local lvl = tonumber(config.get("ai_level", C.DEFAULT_DIFFICULTY)) or C.DEFAULT_DIFFICULTY
    lvl = U.clamp(math.floor(lvl + 0.5), 1, C.MAX_DIFFICULTY)
    return C.DIFFICULTY[lvl] or C.DIFFICULTY[C.DEFAULT_DIFFICULTY]
end

local function move_toward(dx)
    if dx < -6 then return -1 end
    if dx > 6 then return 1 end
    return 0
end

local function move_away(dx)
    if dx < 0 then return 1 end
    if dx > 0 then return -1 end
    return 0
end

local function fallback_lane(obs)
    if obs.enemy_above then return "up" end
    if obs.enemy_below then return "down" end
    return obs.enemy_lane or "mid"
end

local function sword_dir(obs)
    if obs.nearest_sword then
        return move_toward(obs.nearest_sword.dx)
    end
    return 0
end

local function can_path_jump(obs)
    return (obs.player.grounded ~= false) and obs.needs_jump_for_path
end

local function maybe_approach(runtime, obs, lane, ticks, move_dir)
    if can_path_jump(obs) then
        return K.approach_jump(runtime, lane, move_dir, ticks)
    end
    return K.approach(runtime, lane, ticks, move_dir)
end

local function maybe_chase_sword(runtime, obs, lane, ticks, move_dir)
    return K.chase_sword(runtime, lane, ticks, move_dir, can_path_jump(obs))
end

local function should_throw(obs, profile)
    if not obs.self_has_sword then return false end
    if not obs.throw_range then return false end
    if obs.enemy_armed_only then return false end
    if obs.second_sword_dist and obs.second_sword_dist < 72 then return true end
    if profile.unfair and obs.self_armed_only and obs.enemy_wall_trapped then return true end
    if obs.has_go and not obs.goal_contested then return false end
    return U.chance(profile.throw_rate or 0)
end

local function should_lunge(obs, profile)
    if not obs.self_has_sword then return false end
    if not obs.lunge_range then return false end
    if obs.enemy_attack then return false end
    if obs.has_go and not obs.goal_contested then return false end
    return U.chance(profile.lunge_rate or 0)
end

local function enemy_probably_dead(runtime)
    local m = runtime.memory or {}
    return m.enemy_probably_dead and true or false
end

local function live_goal_contested(obs, runtime)
    if not obs.goal_contested then return false end
    if enemy_probably_dead(runtime) then return false end
    return true
end

local function wants_go_rearm(obs, runtime)
    if not obs.has_go or obs.self_has_sword or not obs.nearest_sword then return false end
    if enemy_probably_dead(runtime) then return true end
    if obs.rearm_sword_close then return true end
    if obs.self_sword_advantage then return true end
    return false
end

local function update_memory(runtime, obs)
    runtime.memory = runtime.memory or {
        enemy_lane_counts = { up = 1, mid = 1, down = 1 },
        enemy_last_attack_lane = nil,
        last_x = nil,
        goal_stuck_ticks = 0,
        enemy_still_ticks = 0,
        enemy_probably_dead = false,
        post_kill_ticks = 0,
    }
    local m = runtime.memory
    local lane = obs.enemy_lane or "mid"
    m.enemy_lane_counts[lane] = (m.enemy_lane_counts[lane] or 0) + 1
    if obs.enemy_attack then
        m.enemy_last_attack_lane = lane
        m.enemy_last_attack_tick = obs.tick
    end
    if obs.has_go and obs.player and obs.player.grounded ~= false then
        local x = obs.player.x or 0
        local moving_goalward = ((obs.goal_dir or 1) > 0 and (obs.player_move or 0) > 0) or ((obs.goal_dir or 1) < 0 and (obs.player_move or 0) < 0)
        if m.last_x ~= nil and moving_goalward and math.abs(x - m.last_x) < 1.5 then
            m.goal_stuck_ticks = (m.goal_stuck_ticks or 0) + 1
        else
            m.goal_stuck_ticks = 0
        end
        m.last_x = x
    else
        m.goal_stuck_ticks = 0
        m.last_x = obs.player and obs.player.x or m.last_x
    end

    local enemy_is_still = obs.same_room and obs.enemy_idle_input and obs.enemy_stationary and (obs.hdist < 84)
    if enemy_is_still then
        m.enemy_still_ticks = (m.enemy_still_ticks or 0) + 1
    else
        m.enemy_still_ticks = 0
    end

    m.enemy_probably_dead = obs.has_go and obs.same_room and (not obs.enemy_live_threat) and ((m.enemy_still_ticks or 0) >= 8)
    if m.enemy_probably_dead then
        m.post_kill_ticks = (m.post_kill_ticks or 0) + 1
    else
        m.post_kill_ticks = 0
    end

    m.last_enemy_lane = lane
    runtime.last_obs = obs
end

local function decide_go(obs, runtime, profile)
    local dir = obs.goal_dir or ((runtime.ai_index == 0) and 1 or -1)
    local lane = fallback_lane(obs)
    local stuck = runtime.memory and (runtime.memory.goal_stuck_ticks or 0) >= 2
    local near_exit_obstacle = (obs.player.grounded ~= false) and (obs.at_goal_wall or obs.near_goal_jump or stuck)
    local contested = live_goal_contested(obs, runtime)

    if wants_go_rearm(obs, runtime) and not near_exit_obstacle then
        return maybe_chase_sword(runtime, obs, lane, profile.input_hold_ticks, sword_dir(obs)), enemy_probably_dead(runtime) and "go_rearm_corpse" or "go_rearm"
    end

    if near_exit_obstacle then
        local hard_contest = contested and (
            obs.enemy_armed_only or
            obs.enemy_attack or
            (obs.hdist < 30 and not obs.both_unarmed)
        )
        if not hard_contest then
            return K.go_climb(runtime, dir), stuck and "go_climb_stuck" or "go_climb"
        end
    end

    if contested then
        if obs.self_armed_only and obs.strike_range then
            return K.strike(runtime, O.pick_attack_lane(obs, runtime.memory, profile), move_toward(obs.dx)), "go_clear_kill"
        end
        if obs.enemy_armed_only then
            if obs.nearest_sword and (obs.self_sword_advantage or obs.rearm_sword_close) then
                return maybe_chase_sword(runtime, obs, lane, profile.input_hold_ticks, sword_dir(obs)), "go_rearm_under_threat"
            end
            return K.retreat(runtime, lane, profile.input_hold_ticks, move_away(obs.dx)), "go_defend"
        end
        if obs.strike_range and U.chance(profile.aggression or 0.5) then
            return K.strike(runtime, O.pick_attack_lane(obs, runtime.memory, profile), move_toward(obs.dx)), "go_trade_through"
        end
        if can_path_jump(obs) then
            return K.approach_jump(runtime, lane, dir, profile.input_hold_ticks), "go_hop_past"
        end
        return K.guard(runtime, lane, 1), "go_hold"
    end

    local jump_now = can_path_jump(obs)
    return K.go_run(runtime, dir, jump_now), jump_now and "go_hop_run" or "go_run"
end

local function decide_unarmed(obs, runtime, profile)
    local lane = fallback_lane(obs)
    local sdir = sword_dir(obs)

    if obs.nearest_sword then
        if obs.enemy_has_sword then
            if obs.self_sword_advantage and not obs.close_range then
                return maybe_chase_sword(runtime, obs, lane, profile.input_hold_ticks, sdir), "sword_now"
            end
            if obs.close_range or obs.hdist < 52 then
                return K.retreat(runtime, lane, profile.input_hold_ticks, move_away(obs.dx)), "evade_sword"
            end
            return maybe_chase_sword(runtime, obs, lane, profile.input_hold_ticks, sdir), "sword_race"
        end
        if obs.nearest_sword.dist < 64 or not obs.close_range then
            return maybe_chase_sword(runtime, obs, lane, profile.input_hold_ticks, sdir), "pickup_sword"
        end
    end

    if obs.enemy_has_sword then
        return K.retreat(runtime, lane, profile.input_hold_ticks, move_away(obs.dx)), "stay_alive"
    end

    if obs.close_range and U.chance(profile.aggression or 0.4) then
        return K.strike(runtime, O.pick_attack_lane(obs, runtime.memory, profile), move_toward(obs.dx)), "punch_duel"
    end

    return maybe_approach(runtime, obs, lane, profile.input_hold_ticks, move_toward(obs.dx)), "close_space"
end

local function decide_armed_advantage(obs, runtime, profile)
    local lane = O.pick_attack_lane(obs, runtime.memory, profile)
    if obs.enemy_nearest_sword and obs.enemy_nearest_sword.dist < 44 then
        if can_path_jump(obs) then
            return K.approach_jump(runtime, lane, move_toward(obs.dx), profile.input_hold_ticks), "sword_deny_hop"
        end
        return K.approach(runtime, lane, profile.input_hold_ticks, move_toward(obs.dx)), "sword_deny"
    end
    if obs.strike_range then
        if should_throw(obs, profile) then
            return K.throw(runtime, lane, move_toward(obs.dx), not obs.player.grounded), "pressure_throw"
        end
        return K.strike(runtime, lane, move_toward(obs.dx)), "press_advantage"
    end
    if should_lunge(obs, profile) then
        return K.lunge(runtime, lane, move_toward(obs.dx)), "closing_lunge"
    end
    return maybe_approach(runtime, obs, lane, profile.input_hold_ticks, move_toward(obs.dx)), "pressure_walk"
end

local function decide_head_on(obs, runtime, profile)
    local predicted_lane = O.predicted_attack_lane(obs, runtime.memory)
    local guard_lane = predicted_lane or fallback_lane(obs)
    local attack_lane = O.pick_attack_lane(obs, runtime.memory, profile)

    if obs.enemy_attack and not obs.self_armed_only then
        if profile.unfair or U.chance(profile.guard_bias or 0.0) then
            return K.guard(runtime, guard_lane, profile.input_hold_ticks), "guard_" .. guard_lane
        end
    end

    if obs.strike_range and U.chance(profile.aggression or 0.5) then
        if should_throw(obs, profile) then
            return K.throw(runtime, attack_lane, move_toward(obs.dx), not obs.player.grounded), "duel_throw"
        end
        return K.strike(runtime, attack_lane, move_toward(obs.dx)), "duel_strike_" .. attack_lane
    end

    if should_lunge(obs, profile) then
        return K.lunge(runtime, attack_lane, move_toward(obs.dx)), "duel_lunge_" .. attack_lane
    end

    if U.chance(profile.guard_bias or 0.4) then
        return K.guard(runtime, guard_lane, profile.input_hold_ticks), "hold_lane_" .. guard_lane
    end

    return maybe_approach(runtime, obs, attack_lane, profile.input_hold_ticks, move_toward(obs.dx)), "duel_approach"
end

local function decide_action(obs, runtime)
    local profile = get_profile()
    runtime.profile = profile

    if obs.start_countdown > 0 or obs.end_countdown > 0 then
        return K.idle(runtime, 1), "round_lock"
    end

    if enemy_probably_dead(runtime) then
        local lane = fallback_lane(obs)
        if obs.has_go then
            return decide_go(obs, runtime, profile)
        end
        if not obs.self_has_sword and obs.nearest_sword then
            return maybe_chase_sword(runtime, obs, lane, profile.input_hold_ticks, sword_dir(obs)), "corpse_rearm"
        end
        return K.approach(runtime, lane, 1, obs.goal_dir or 0), "corpse_reset"
    end

    if obs.has_go then
        return decide_go(obs, runtime, profile)
    end

    if U.chance(profile.noise or 0) then
        local lane = fallback_lane(obs)
        local move = move_toward(obs.dx)
        if U.chance(0.45) then
            return K.guard(runtime, lane, profile.input_hold_ticks), "noise_guard"
        end
        return maybe_approach(runtime, obs, lane, profile.input_hold_ticks, move), "noise_walk"
    end

    if obs.enemy_armed_only or obs.both_unarmed then
        return decide_unarmed(obs, runtime, profile)
    end

    if obs.self_armed_only then
        return decide_armed_advantage(obs, runtime, profile)
    end

    return decide_head_on(obs, runtime, profile)
end

function M.new(ai_index)
    return {
        ai_index = ai_index or 1,
        sequence = nil,
        current_label = C.ACTIONS.IDLE,
        current_reason = "",
        last_plan_tick = -999,
        memory = nil,
        session_round = 0,
        last_input = {},
    }
end

function M.tick(runtime)
    local profile = get_profile()
    local obs = O.snapshot(runtime.ai_index, true)
    runtime.profile = profile
    runtime.last_obs = obs

    if not obs or not obs.in_game then
        K.clear(runtime)
        return
    end

    update_memory(runtime, obs)

    local need_new_plan = (not runtime.sequence)
    if not need_new_plan then
        local ticks_since_plan = (obs.tick or 0) - (runtime.last_plan_tick or 0)
        if ticks_since_plan >= (profile.reaction_ticks or 1) then
            need_new_plan = true
        end
        if obs.has_go and obs.goal_contested then
            need_new_plan = true
        end
    end

    if need_new_plan then
        local seq, why = decide_action(obs, runtime)
        runtime.sequence = seq
        runtime.current_label = seq and seq.label or C.ACTIONS.IDLE
        runtime.current_reason = why or runtime.current_label
        runtime.last_plan_tick = obs.tick or 0
        L.log_decision(obs, profile.label, runtime.current_reason)
    end

    K.tick(runtime)
end

return M
