local M = {}

M.LANES = { "up", "mid", "down" }
M.LANE_INDEX = { up = 1, mid = 2, down = 3 }
M.LANE_LABEL = { up = "Top", mid = "Middle", down = "Bottom" }
M.OPPOSITE_LANES = {
    up = { "mid", "down" },
    mid = { "up", "down" },
    down = { "up", "mid" },
}

M.DIFFICULTY = {
    [1] = {
        id = 1,
        key = "newbie",
        label = "1 - Newbie",
        short = "Newbie",
        reaction_ticks = 12,
        input_hold_ticks = 4,
        mistake_rate = 0.35,
        lunge_rate = 0.00,
        throw_rate = 0.00,
        aggression = 0.22,
        guard_bias = 0.74,
        jump_rate = 0.00,
        noise = 0.32,
        perfect_info = false,
    },
    [2] = {
        id = 2,
        key = "learner",
        label = "2 - Learner",
        short = "Learner",
        reaction_ticks = 8,
        input_hold_ticks = 4,
        mistake_rate = 0.22,
        lunge_rate = 0.05,
        throw_rate = 0.01,
        aggression = 0.34,
        guard_bias = 0.64,
        jump_rate = 0.01,
        noise = 0.18,
        perfect_info = false,
    },
    [3] = {
        id = 3,
        key = "competent",
        label = "3 - Competent",
        short = "Competent",
        reaction_ticks = 4,
        input_hold_ticks = 3,
        mistake_rate = 0.10,
        lunge_rate = 0.12,
        throw_rate = 0.04,
        aggression = 0.52,
        guard_bias = 0.48,
        jump_rate = 0.02,
        noise = 0.10,
        perfect_info = false,
    },
    [4] = {
        id = 4,
        key = "expert",
        label = "4 - Expert",
        short = "Expert",
        reaction_ticks = 2,
        input_hold_ticks = 2,
        mistake_rate = 0.04,
        lunge_rate = 0.20,
        throw_rate = 0.08,
        aggression = 0.62,
        guard_bias = 0.34,
        jump_rate = 0.03,
        noise = 0.05,
        perfect_info = true,
    },
    [5] = {
        id = 5,
        key = "master",
        label = "5 - Master",
        short = "Master",
        reaction_ticks = 1,
        input_hold_ticks = 2,
        mistake_rate = 0.01,
        lunge_rate = 0.26,
        throw_rate = 0.12,
        aggression = 0.72,
        guard_bias = 0.24,
        jump_rate = 0.04,
        noise = 0.02,
        perfect_info = true,
    },
    [6] = {
        id = 6,
        key = "pain_kink",
        label = "Pain Kink Mode",
        short = "Pain Kink",
        reaction_ticks = 1,
        input_hold_ticks = 1,
        mistake_rate = 0.00,
        lunge_rate = 0.40,
        throw_rate = 0.30,
        aggression = 0.96,
        guard_bias = 0.06,
        jump_rate = 0.06,
        noise = 0.00,
        perfect_info = true,
        unfair = true,
        use_direct_control = true,
    },
}

M.MAX_DIFFICULTY = 6
M.DEFAULT_DIFFICULTY = 3

M.CMD = {
    JUMP = mod.game.CMD_JUMP or 0x01,
    ATTACK = mod.game.CMD_ATTACK or 0x02,
    RIGHT = mod.game.CMD_RIGHT or 0x04,
    LEFT = mod.game.CMD_LEFT or 0x08,
    UP = mod.game.CMD_UP or 0x10,
    DOWN = mod.game.CMD_DOWN or 0x20,
    MENU = mod.game.CMD_MENU or 0x40,
}

M.THING_TYPE = {
    PLAYER = 0x01,
    SWORD = 0x02,
}

M.ACTIONS = {
    IDLE = "idle",
    APPROACH = "approach",
    RETREAT = "retreat",
    CHASE_SWORD = "chase_sword",
    STRIKE = "strike",
    LUNGE = "lunge",
    THROW = "throw",
    AIR_THROW = "air_throw",
    GUARD = "guard",
    JUMP_IN = "jump_in",
    GO_RUN = "go_run",
    GO_JUMP = "go_jump",
    SWORD_DENY = "sword_deny",
    EVADE = "evade",
    RESET = "reset",
}

return M
