local C = mod.dofile("lib/constants.lua")

local M = {}

local function cmd_table(move, lane, jump, attack)
    local t = {}
    if move == -1 then t.left = true end
    if move == 1 then t.right = true end
    if lane == "up" then t.up = true end
    if lane == "down" then t.down = true end
    if jump then t.jump = true end
    if attack then t.attack = true end
    return t
end

local function sequence(label, steps)
    return {
        label = label,
        steps = steps or {},
        index = 1,
        ticks_left = nil,
    }
end

local function apply_input(runtime, input)
    mod.game.set_input(runtime.ai_index, input or {}, 1, true)
    mod.game.input_override(runtime.ai_index, input or {}, 4, true)
    runtime.last_input = input or {}
end

function M.clear(runtime)
    runtime.sequence = nil
    runtime.current_label = C.ACTIONS.IDLE
    runtime.last_input = {}
    mod.game.input_clear(runtime.ai_index)
end

function M.idle(runtime, ticks)
    return sequence(C.ACTIONS.IDLE, {
        { ticks = ticks or 1, input = {} },
    })
end

function M.approach(runtime, lane, ticks, move_dir)
    return sequence(C.ACTIONS.APPROACH, {
        { ticks = ticks or 2, input = cmd_table(move_dir or 0, lane or "mid", false, false) },
    })
end

function M.approach_jump(runtime, lane, move_dir, hold_ticks)
    return sequence(C.ACTIONS.JUMP_IN, {
        { ticks = 2, input = cmd_table(move_dir or 0, lane or "mid", true, false) },
        { ticks = hold_ticks or 3, input = cmd_table(move_dir or 0, lane or "mid", false, false) },
    })
end

function M.retreat(runtime, lane, ticks, move_dir)
    return sequence(C.ACTIONS.RETREAT, {
        { ticks = ticks or 2, input = cmd_table(move_dir or 0, lane or "mid", false, false) },
    })
end

function M.guard(runtime, lane, ticks)
    return sequence(C.ACTIONS.GUARD, {
        { ticks = ticks or 2, input = cmd_table(0, lane or "mid", false, false) },
    })
end

function M.chase_sword(runtime, lane, ticks, move_dir, jump)
    return sequence(C.ACTIONS.CHASE_SWORD, {
        { ticks = ticks or 2, input = cmd_table(move_dir or 0, lane or "mid", jump and true or false, false) },
    })
end

function M.go_run(runtime, move_dir, jump_now)
    return sequence(jump_now and C.ACTIONS.GO_JUMP or C.ACTIONS.GO_RUN, {
        { ticks = jump_now and 2 or 1, input = cmd_table(move_dir or 0, "mid", jump_now and true or false, false) },
        { ticks = 3, input = cmd_table(move_dir or 0, "mid", false, false) },
    })
end

function M.go_climb(runtime, move_dir)
    return sequence(C.ACTIONS.GO_JUMP, {
        { ticks = 2, input = cmd_table(move_dir or 0, "mid", true, false) },
        { ticks = 5, input = cmd_table(move_dir or 0, "mid", false, false) },
    })
end

function M.strike(runtime, lane, move_dir)
    return sequence(C.ACTIONS.STRIKE .. ":" .. (lane or "mid"), {
        { ticks = 1, input = cmd_table(move_dir or 0, lane or "mid", false, true) },
        { ticks = 1, input = cmd_table(move_dir or 0, lane or "mid", false, false) },
    })
end

function M.lunge(runtime, lane, move_dir)
    return sequence(C.ACTIONS.LUNGE .. ":" .. (lane or "mid"), {
        { ticks = 2, input = cmd_table(move_dir or 0, lane or "mid", false, true) },
        { ticks = 1, input = cmd_table(move_dir or 0, lane or "mid", false, false) },
        { ticks = 1, input = cmd_table(move_dir or 0, lane or "mid", false, false) },
    })
end

function M.throw(runtime, lane, move_dir, airborne)
    local label = airborne and C.ACTIONS.AIR_THROW or C.ACTIONS.THROW
    return sequence(label .. ":" .. (lane or "mid"), {
        { ticks = airborne and 2 or 3, input = cmd_table(move_dir or 0, lane or "mid", false, true) },
        { ticks = 1, input = cmd_table(move_dir or 0, lane or "mid", false, false) },
        { ticks = 1, input = cmd_table(0, lane or "mid", false, false) },
    })
end

function M.tick(runtime)
    local seq = runtime.sequence
    if not seq then
        apply_input(runtime, {})
        runtime.current_label = C.ACTIONS.IDLE
        return
    end

    local step = seq.steps[seq.index]
    if not step then
        runtime.sequence = nil
        runtime.current_label = C.ACTIONS.IDLE
        apply_input(runtime, {})
        return
    end

    if not seq.ticks_left then
        seq.ticks_left = step.ticks or 1
    end

    apply_input(runtime, step.input or {})
    seq.ticks_left = seq.ticks_left - 1

    if seq.ticks_left <= 0 then
        seq.index = seq.index + 1
        seq.ticks_left = nil
        if not seq.steps[seq.index] then
            runtime.sequence = nil
            runtime.current_label = C.ACTIONS.IDLE
        end
    end
end

return M
