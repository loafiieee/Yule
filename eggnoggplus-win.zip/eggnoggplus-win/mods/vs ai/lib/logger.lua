local U = mod.dofile("lib/util.lua")

local M = {
    path = mod.get_path("training_log.tsv"),
}

local HEADER = table.concat({
    "tick", "difficulty", "action", "go", "self_x", "self_y", "enemy_x", "enemy_y",
    "self_has_sword", "enemy_has_sword", "self_lane", "enemy_lane", "hdist", "vdist",
    "nearest_sword_dx", "nearest_sword_dy", "tiles", "entities"
}, "\t")

local function encode_entities(entities)
    local out = {}
    for _, ent in ipairs(entities or {}) do
        out[#out + 1] = table.concat({
            ent.type or 0,
            U.round(ent.x or 0),
            U.round(ent.y or 0),
            U.round(ent.vx or 0),
            U.round(ent.vy or 0),
            ent.state_id or 0,
            ent.flags or 0,
        }, ",")
    end
    return table.concat(out, ";")
end

function M.log_decision(obs, difficulty_label, action_label)
    if not config.get("log_training", false) then return end
    if not U.ensure_file_header(M.path, HEADER) then return end
    local f = io.open(M.path, "a")
    if not f then return end
    local sword = obs.nearest_sword or {}
    local row = {
        obs.tick or 0,
        difficulty_label or "",
        action_label or "",
        obs.has_go and 1 or 0,
        U.round(obs.player.x or 0),
        U.round(obs.player.y or 0),
        U.round(obs.enemy.x or 0),
        U.round(obs.enemy.y or 0),
        obs.self_has_sword and 1 or 0,
        obs.enemy_has_sword and 1 or 0,
        obs.player_lane or "",
        obs.enemy_lane or "",
        U.round(obs.hdist or 0),
        U.round(obs.vdist or 0),
        U.round(sword.dx or 0),
        U.round(sword.dy or 0),
        obs.tiles_compact or "",
        encode_entities(obs.entities),
    }
    for i = 1, #row do
        row[i] = U.tsv_escape(row[i])
    end
    f:write(table.concat(row, "\t"), "\n")
    f:close()
end

return M
