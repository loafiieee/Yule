local C = mod.dofile("lib/constants.lua")
local U = mod.dofile("lib/util.lua")

local M = {}

local function lane_from_cmd_bits(cmd_bits)
    if U.has_flag(cmd_bits or 0, C.CMD.UP) then return "up" end
    if U.has_flag(cmd_bits or 0, C.CMD.DOWN) then return "down" end
    return "mid"
end

local function move_from_cmd_bits(cmd_bits)
    if U.has_flag(cmd_bits or 0, C.CMD.LEFT) and not U.has_flag(cmd_bits or 0, C.CMD.RIGHT) then return -1 end
    if U.has_flag(cmd_bits or 0, C.CMD.RIGHT) and not U.has_flag(cmd_bits or 0, C.CMD.LEFT) then return 1 end
    return 0
end

local function nearest_sword(obs, from_player)
    local best, best_d2
    for _, ent in ipairs(obs.entities or {}) do
        if ent.type == C.THING_TYPE.SWORD and ent.active then
            local dx = (ent.x or 0) - (from_player.x or 0)
            local dy = (ent.y or 0) - (from_player.y or 0)
            local d2 = dx * dx + dy * dy
            if not best or d2 < best_d2 then
                best = {
                    entity = ent,
                    x = ent.x or 0,
                    y = ent.y or 0,
                    dx = dx,
                    dy = dy,
                    dist2 = d2,
                    dist = math.sqrt(d2),
                }
                best_d2 = d2
            end
        end
    end
    return best
end

local function second_sword_distance(obs, from_player, exclude)
    local best_d2
    for _, ent in ipairs(obs.entities or {}) do
        if ent.type == C.THING_TYPE.SWORD and ent.active and ent ~= exclude then
            local dx = (ent.x or 0) - (from_player.x or 0)
            local dy = (ent.y or 0) - (from_player.y or 0)
            local d2 = dx * dx + dy * dy
            if not best_d2 or d2 < best_d2 then
                best_d2 = d2
            end
        end
    end
    if not best_d2 then return nil end
    return math.sqrt(best_d2)
end

local function compact_tiles(tiles)
    local out = {}
    for y, row in ipairs(tiles or {}) do
        local row_out = {}
        for x, tile in ipairs(row or {}) do
            row_out[#row_out + 1] = tostring(tile or -1)
        end
        out[y] = table.concat(row_out, ",")
    end
    return table.concat(out, "/")
end

function M.snapshot(player_index, include_tiles)
    local raw = mod.game.snapshot(player_index, include_tiles ~= false)
    if not raw then return nil end

    local player = raw.player or {}
    local enemy = raw.enemy or {}
    local obs = {
        tick = raw.tick or 0,
        in_game = raw.in_game and true or false,
        start_countdown = raw.start_countdown or 0,
        end_countdown = raw.end_countdown or 0,
        leader_index = raw.leader_index,
        room_index = raw.room_index or 0,
        room_width = raw.room_width or 0,
        room_height = raw.room_height or 0,
        player = player,
        enemy = enemy,
        entities = raw.entities or {},
        tiles = raw.tiles_of_current_room,
        player_lane = lane_from_cmd_bits(player.cmd_bits),
        enemy_lane = lane_from_cmd_bits(enemy.cmd_bits),
        player_move = move_from_cmd_bits(player.cmd_bits),
        enemy_move = move_from_cmd_bits(enemy.cmd_bits),
    }

    obs.dx = (enemy.x or 0) - (player.x or 0)
    obs.dy = (enemy.y or 0) - (player.y or 0)
    obs.hdist = U.abs(obs.dx)
    obs.vdist = U.abs(obs.dy)
    obs.close_range = obs.hdist < 26
    obs.strike_range = obs.hdist < 42
    obs.lunge_range = obs.hdist >= 26 and obs.hdist < 74
    obs.throw_range = obs.hdist >= 48 and obs.hdist < 132
    obs.enemy_above = obs.dy < -10
    obs.enemy_below = obs.dy > 10

    obs.self_has_sword = player.has_sword and true or false
    obs.enemy_has_sword = enemy.has_sword and true or false
    obs.both_armed = obs.self_has_sword and obs.enemy_has_sword
    obs.self_armed_only = obs.self_has_sword and not obs.enemy_has_sword
    obs.enemy_armed_only = (not obs.self_has_sword) and obs.enemy_has_sword
    obs.both_unarmed = (not obs.self_has_sword) and (not obs.enemy_has_sword)

    obs.player_attack = U.has_flag(player.cmd_bits or 0, C.CMD.ATTACK)
    obs.enemy_attack = U.has_flag(enemy.cmd_bits or 0, C.CMD.ATTACK)
    obs.player_jump = U.has_flag(player.cmd_bits or 0, C.CMD.JUMP)
    obs.enemy_jump = U.has_flag(enemy.cmd_bits or 0, C.CMD.JUMP)
    obs.player_speed = U.abs(player.vx or 0) + U.abs(player.vy or 0)
    obs.enemy_speed = U.abs(enemy.vx or 0) + U.abs(enemy.vy or 0)
    obs.enemy_idle_input = (obs.enemy_move == 0) and (not obs.enemy_attack) and (not obs.enemy_jump)
    obs.enemy_stationary = obs.enemy_speed < 1.1

    obs.nearest_sword = nearest_sword(obs, player)
    obs.enemy_nearest_sword = nearest_sword(obs, enemy)
    obs.second_sword_dist = second_sword_distance(obs, player, obs.nearest_sword and obs.nearest_sword.entity or nil)

    obs.self_wall_trapped = (player.wall_left or false) or (player.wall_right or false)
    obs.enemy_wall_trapped = (enemy.wall_left or false) or (enemy.wall_right or false)
    obs.player_lane_idx = C.LANE_INDEX[obs.player_lane] or 2
    obs.enemy_lane_idx = C.LANE_INDEX[obs.enemy_lane] or 2

    obs.same_room = (player.room_index or obs.room_index) == (enemy.room_index or obs.room_index)
    obs.enemy_live_threat = obs.same_room and (obs.enemy_has_sword or obs.enemy_attack or obs.enemy_jump or (obs.enemy_move ~= 0) or (obs.enemy_speed > 1.6))
    obs.has_go = raw.leader_index ~= nil and raw.leader_index == (player.index or player_index)
    obs.enemy_has_go = raw.leader_index ~= nil and raw.leader_index == (enemy.index or ((player_index + 1) % 2))
    obs.goal_dir = ((player.index or player_index) == 0) and 1 or -1
    obs.at_goal_wall = (obs.goal_dir > 0 and player.wall_right) or (obs.goal_dir < 0 and player.wall_left) or false
    obs.goal_wall_distance = obs.goal_dir > 0 and (obs.room_width - (player.x or 0)) or (player.x or 0)
    obs.near_goal_jump = (player.grounded ~= false) and (obs.goal_wall_distance ~= nil and obs.goal_wall_distance < 56)
    obs.enemy_between_goal = obs.same_room and (((obs.goal_dir > 0) and ((enemy.x or 0) >= ((player.x or 0) - 6))) or ((obs.goal_dir < 0) and ((enemy.x or 0) <= ((player.x or 0) + 6))))
    obs.goal_contested = obs.has_go and obs.enemy_between_goal and (obs.hdist < 88)
    obs.rearm_sword_close = obs.nearest_sword and obs.nearest_sword.dist < 132 or false

    obs.wall_ahead = ((obs.goal_dir > 0 and player.wall_right) or (obs.goal_dir < 0 and player.wall_left) or false)
    if obs.dx > 0 and player.wall_right then obs.wall_ahead = true end
    if obs.dx < 0 and player.wall_left then obs.wall_ahead = true end
    obs.needs_jump_for_path = (player.grounded ~= false) and (obs.wall_ahead or (obs.enemy_above and obs.hdist < 72) or obs.near_goal_jump)

    if obs.nearest_sword and obs.enemy_nearest_sword then
        obs.self_sword_advantage = (obs.nearest_sword.dist + 8) < obs.enemy_nearest_sword.dist
        obs.enemy_sword_advantage = (obs.enemy_nearest_sword.dist + 8) < obs.nearest_sword.dist
    elseif obs.nearest_sword then
        obs.self_sword_advantage = true
        obs.enemy_sword_advantage = false
    elseif obs.enemy_nearest_sword then
        obs.self_sword_advantage = false
        obs.enemy_sword_advantage = true
    else
        obs.self_sword_advantage = false
        obs.enemy_sword_advantage = false
    end

    obs.tiles_compact = obs.tiles and compact_tiles(obs.tiles) or ""

    return obs
end

function M.predicted_attack_lane(obs, memory)
    if obs.enemy_attack then
        return obs.enemy_lane
    end
    memory = memory or {}
    local counts = memory.enemy_lane_counts or { up = 1, mid = 1, down = 1 }
    local best_lane = obs.enemy_lane or "mid"
    local best_score = counts[best_lane] or 0
    for _, lane in ipairs(C.LANES) do
        local score = counts[lane] or 0
        if score > best_score then
            best_lane = lane
            best_score = score
        end
    end
    return best_lane
end

function M.pick_attack_lane(obs, memory, profile)
    if obs.enemy_above then return "up" end
    if obs.enemy_below then return "down" end

    local predicted_guard = M.predicted_attack_lane(obs, memory)
    local options = U.copy_table(C.OPPOSITE_LANES[predicted_guard] or C.OPPOSITE_LANES.mid)

    if profile and profile.perfect_info and obs.enemy_lane and obs.enemy_lane ~= "mid" then
        options = U.copy_table(C.OPPOSITE_LANES[obs.enemy_lane])
    end

    if memory and memory.enemy_last_attack_lane and U.chance(0.35) then
        local counter_options = C.OPPOSITE_LANES[memory.enemy_last_attack_lane]
        if counter_options then
            options = U.copy_table(counter_options)
        end
    end

    if profile and U.chance(profile.mistake_rate or 0) then
        return U.pick(C.LANES)
    end

    return U.pick(options) or "mid"
end

return M
