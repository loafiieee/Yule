local M = {}

function M.clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

function M.sign(v)
    if v > 0 then return 1 end
    if v < 0 then return -1 end
    return 0
end

function M.abs(v)
    if v < 0 then return -v end
    return v
end

function M.round(v)
    if v >= 0 then return math.floor(v + 0.5) end
    return math.ceil(v - 0.5)
end

function M.has_flag(bits, flag)
    if not bits or not flag or flag <= 0 then return false end
    local span = flag * 2
    return (bits % span) >= flag
end

function M.copy_table(src)
    local dst = {}
    for k, v in pairs(src or {}) do
        if type(v) == "table" then
            dst[k] = M.copy_table(v)
        else
            dst[k] = v
        end
    end
    return dst
end

function M.shuffle_in_place(t)
    for i = #t, 2, -1 do
        local j = math.random(i)
        t[i], t[j] = t[j], t[i]
    end
    return t
end

function M.pick(list)
    if not list or #list == 0 then return nil end
    return list[math.random(#list)]
end

function M.chance(p)
    if not p or p <= 0 then return false end
    if p >= 1 then return true end
    return math.random() < p
end

function M.weighted_pick(weight_map)
    local total = 0
    for _, item in ipairs(weight_map or {}) do
        if item.weight and item.weight > 0 then
            total = total + item.weight
        end
    end
    if total <= 0 then return nil end
    local roll = math.random() * total
    local acc = 0
    for _, item in ipairs(weight_map) do
        if item.weight and item.weight > 0 then
            acc = acc + item.weight
            if roll <= acc then
                return item.value
            end
        end
    end
    return weight_map[#weight_map] and weight_map[#weight_map].value or nil
end

function M.ensure_file_header(path, header)
    local f = io.open(path, "r")
    if f then
        local first = f:read("*l")
        f:close()
        if first and first ~= "" then return true end
    end
    f = io.open(path, "w")
    if not f then return false end
    f:write(header)
    if header:sub(-1) ~= "\n" then f:write("\n") end
    f:close()
    return true
end

function M.tsv_escape(v)
    if v == nil then return "" end
    v = tostring(v)
    v = v:gsub("\t", " "):gsub("\r", " "):gsub("\n", " ")
    return v
end

function M.join(list, sep)
    return table.concat(list or {}, sep or ",")
end

return M
