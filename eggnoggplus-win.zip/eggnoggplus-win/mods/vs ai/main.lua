local C = mod.dofile("lib/constants.lua")
local U = mod.dofile("lib/util.lua")
local BOT = mod.dofile("lib/bot.lua")

math.randomseed(os.time())
math.random(); math.random(); math.random()

local START_ACTION_PTR = 0x432440
local HUMAN_GLYPH = 0x9E
local AI_GLYPH = 0x86

if mod.font and mod.font.alloc_glyph then
    local b, err = mod.font.alloc_glyph("icons/ai_8x8.png")
    if b then
        AI_GLYPH = b
    else
        mod.warn("alloc_glyph failed (icons/ai_8x8.png): " .. tostring(err))
    end
end

local LABEL_HUMAN = "VS " .. string.char(HUMAN_GLYPH)
local LABEL_AI = "VS " .. string.char(AI_GLYPH)
local GAP = 10.0

local runtime = BOT.new(1)
local last_start_ptr = nil
local baseline_captured = false
local baseline_from_initial = false
local base_x, base_y, base_w, base_h = nil, nil, nil, nil
local was_in_main = false
local was_in_pregame = false

local pregame = {
    active = false,
    activity = { 0, 0 },
    confirm = { 0, 0 },
    last_tick = { -1, -1 },
    human_index = nil,
    ai_index = nil,
}

local function difficulty_level()
    local lvl = tonumber(config.get("ai_level", C.DEFAULT_DIFFICULTY)) or C.DEFAULT_DIFFICULTY
    lvl = U.clamp(math.floor(lvl + 0.5), 1, C.MAX_DIFFICULTY)
    return lvl
end

local function difficulty_label()
    local d = C.DIFFICULTY[difficulty_level()] or C.DIFFICULTY[C.DEFAULT_DIFFICULTY]
    return d.label
end

local function in_main_menu_state(st)
    return st == "main" or st == "main_initial"
end

local function in_pregame_state(st)
    return st == "pregame"
end

local function cfg_set_bool(key, val)
    if not (config and config.get and config.set) then return end
    local cur = config.get(key, false)
    local want = val and true or false
    local have = cur and true or false
    if have ~= want then
        config.set(key, want)
    end
end

local function reset_match_assignment()
    pregame.active = false
    pregame.activity[1], pregame.activity[2] = 0, 0
    pregame.confirm[1], pregame.confirm[2] = 0, 0
    pregame.last_tick[1], pregame.last_tick[2] = -1, -1
    pregame.human_index = nil
    pregame.ai_index = nil
    runtime.ai_index = 1
    mod.game.input_clear(0)
    mod.game.input_clear(1)
    runtime.sequence = nil
    runtime.current_label = C.ACTIONS.IDLE
    runtime.current_reason = ""
    runtime.last_plan_tick = -999
    runtime.last_obs = nil
    runtime.last_input = {}
end

local function assign_from_pregame(reason)
    if pregame.ai_index ~= nil and pregame.human_index ~= nil then return end

    local human = nil
    if pregame.confirm[1] ~= pregame.confirm[2] then
        human = (pregame.confirm[1] > pregame.confirm[2]) and 0 or 1
    elseif pregame.activity[1] ~= pregame.activity[2] then
        human = (pregame.activity[1] > pregame.activity[2]) and 0 or 1
    elseif pregame.last_tick[1] ~= pregame.last_tick[2] then
        human = (pregame.last_tick[1] > pregame.last_tick[2]) and 0 or 1
    else
        human = 0
    end

    pregame.human_index = human
    pregame.ai_index = 1 - human
    runtime.ai_index = pregame.ai_index
    mod.game.input_clear(0)
    mod.game.input_clear(1)
    runtime.sequence = nil
    runtime.current_label = C.ACTIONS.IDLE
    runtime.current_reason = "assigned:" .. tostring(reason or "pregame")
    runtime.last_plan_tick = -999
    mod.log(("VS AI owner resolved: human=%d ai=%d (%s; activity=%d/%d confirm=%d/%d)")
        :format(pregame.human_index, pregame.ai_index, tostring(reason or "pregame"),
            pregame.activity[1], pregame.activity[2], pregame.confirm[1], pregame.confirm[2]))
end

local function update_pregame_activity()
    for player = 0, 1 do
        local raw = mod.game.poll_cmds_raw(player, 1) or 0
        local idx = player + 1
        if raw ~= 0 then
            pregame.activity[idx] = pregame.activity[idx] + 1
            pregame.last_tick[idx] = mod.game.tick_count() or pregame.last_tick[idx]
            if U.has_flag(raw, C.CMD.MENU) or U.has_flag(raw, C.CMD.ATTACK) or U.has_flag(raw, C.CMD.JUMP) then
                pregame.confirm[idx] = pregame.confirm[idx] + 1
            end
        end
    end
end

local function capture_start_ptr_and_baseline(state_name)
    local ptr = mod.ui.find_button_by_action_ptr(START_ACTION_PTR)
    if not ptr then return nil end

    last_start_ptr = ptr
    local want_capture = (not baseline_captured) or (baseline_from_initial and state_name == "main")
    if want_capture then
        local x, y, w, h = mod.ui.button_rect_ptr(ptr)
        if (x and y and w and h and w > 20.0 and h > 10.0) then
            base_x, base_y, base_w, base_h = x, y, w, h
            baseline_captured = true
            baseline_from_initial = (state_name == "main_initial")
            if state_name == "main" then baseline_from_initial = false end
        end
    end

    return ptr
end

local function dispatch_start(ptr)
    if not ptr then return end
    local fn = mod.ui.button_invoke_ptr or mod.ui.button_activate_ptr
    if not fn then return end

    local before = mod.ui.state_name()
    local codes = { 1, 3, 0, 2, 4 }
    for _, code in ipairs(codes) do
        local ret, err = fn(ptr, code)
        if ret == nil then
            mod.warn("start dispatch failed (code=" .. tostring(code) .. "): " .. tostring(err))
        end
        local after = mod.ui.state_name()
        if after ~= before then return end
    end
end

mod.on_event(function(e)
    if e.type ~= "mousebuttondown" or e.button ~= 1 then
        return false
    end

    local st = mod.ui.state_name()
    if not in_main_menu_state(st) then
        return false
    end

    local ptr = mod.ui.find_button_by_action_ptr(START_ACTION_PTR)
    if not ptr then return false end

    local x, y, w, h = mod.ui.button_rect_ptr(ptr)
    if not (x and y and w and h) then return false end

    if math.abs(e.x - x) <= (w * 0.5) and math.abs(e.y - y) <= (h * 0.5) then
        cfg_set_bool("vs_ai", false)
    end

    return false
end)

mod.on_tick(function()
    local st = mod.ui.state_name()

    if config.get("vs_ai", false) and in_pregame_state(st) then
        if not was_in_pregame then
            pregame.active = true
            pregame.activity[1], pregame.activity[2] = 0, 0
            pregame.confirm[1], pregame.confirm[2] = 0, 0
            pregame.last_tick[1], pregame.last_tick[2] = -1, -1
            pregame.human_index = nil
            pregame.ai_index = nil
            runtime.sequence = nil
        end
        update_pregame_activity()
        was_in_pregame = true
        mod.game.input_clear(0)
        mod.game.input_clear(1)
        return
    end

    if was_in_pregame and config.get("vs_ai", false) and not in_pregame_state(st) then
        assign_from_pregame("pregame_exit")
        was_in_pregame = false
    elseif not in_pregame_state(st) then
        was_in_pregame = false
    end

    if config.get("vs_ai", false) then
        if pregame.ai_index == nil then
            assign_from_pregame("fallback")
        end
        BOT.tick(runtime)
    else
        mod.game.input_clear(0)
        mod.game.input_clear(1)
        runtime.current_label = C.ACTIONS.IDLE
        runtime.current_reason = ""
    end
end)

mod.on_frame(function()
    local st = mod.ui.state_name()
    local in_main = in_main_menu_state(st)
    local in_pregame = in_pregame_state(st)

    if in_main and not was_in_main then
        cfg_set_bool("vs_ai", false)
        reset_match_assignment()
    end
    was_in_main = in_main

    if config.get("vs_ai", false) and in_pregame then
        if not was_in_pregame then
            pregame.active = true
            pregame.activity[1], pregame.activity[2] = 0, 0
            pregame.confirm[1], pregame.confirm[2] = 0, 0
            pregame.last_tick[1], pregame.last_tick[2] = -1, -1
            pregame.human_index = nil
            pregame.ai_index = nil
        end
        update_pregame_activity()
        was_in_pregame = true
    elseif was_in_pregame and config.get("vs_ai", false) and not in_pregame then
        assign_from_pregame("pregame_frame_exit")
        was_in_pregame = false
    elseif not in_pregame then
        was_in_pregame = false
    end

    if not in_main then
        baseline_captured = false
        baseline_from_initial = false
        base_x, base_y, base_w, base_h = nil, nil, nil, nil
    else
        local start_ptr = capture_start_ptr_and_baseline(st)
        if start_ptr then
            if mod.ui.button_set_label_ptr then
                mod.ui.button_set_label_ptr(start_ptr, LABEL_HUMAN)
            end

            local clicked_ai = mod.ui.native_button("vs_ai", LABEL_AI, 1.0, 4.5, 3.0, 6.0)

            if base_w and base_h and base_x and base_y then
                local gap = GAP
                if gap < 0.0 then gap = 0.0 end
                local w_each = (base_w - gap) * 0.5
                if w_each < 40.0 then
                    gap = 0.0
                    w_each = base_w * 0.5
                end
                local left_edge = base_x - (base_w * 0.5)
                local human_x = left_edge + (w_each * 0.5)
                local ai_x = human_x + w_each + gap

                if mod.ui.button_resize_ptr then
                    mod.ui.button_resize_ptr(start_ptr, w_each, base_h)
                end
                if mod.ui.button_set_pos_ptr then
                    mod.ui.button_set_pos_ptr(start_ptr, human_x, base_y)
                end

                mod.ui.native_resize("vs_ai", w_each, base_h)
                mod.ui.native_set_pos("vs_ai", ai_x, base_y)
            end

            if clicked_ai then
                cfg_set_bool("vs_ai", true)
                reset_match_assignment()
                dispatch_start(last_start_ptr)
            end
        end
    end

    if config.get("debug_overlay", true) and runtime.last_obs and runtime.last_obs.in_game and config.get("vs_ai", false) then
        local status = mod.game.input_status(runtime.ai_index) or {}
        mod.ui.layout(16, 16, 16, 4, 380, 0.85)
        mod.ui.text("VS AI - " .. difficulty_label(), 1.0, 1.0, 1.0, 0.85)
        mod.ui.text(("Human=%s AI=%s GO=%s"):format(tostring(pregame.human_index), tostring(runtime.ai_index), tostring(runtime.last_obs.has_go)), 1.0, 1.0, 1.0, 0.85)
        mod.ui.text("Intent: " .. tostring(runtime.current_reason or runtime.current_label), 1.0, 1.0, 1.0, 0.85)
        mod.ui.text(("Tick %d  dx %.1f dy %.1f"):format(runtime.last_obs.tick or 0, runtime.last_obs.dx or 0, runtime.last_obs.dy or 0), 1.0, 1.0, 1.0, 0.85)
        mod.ui.text(("Sword: self=%s enemy=%s near=%.1f"):format(
            tostring(runtime.last_obs.self_has_sword),
            tostring(runtime.last_obs.enemy_has_sword),
            runtime.last_obs.nearest_sword and runtime.last_obs.nearest_sword.dist or -1
        ), 1.0, 1.0, 1.0, 0.85)
        mod.ui.text(("Corpse=%s stuck=%s state=%s"):format(
            tostring(runtime.memory and runtime.memory.enemy_probably_dead or false),
            tostring(runtime.memory and runtime.memory.goal_stuck_ticks or 0),
            tostring(runtime.last_obs.enemy and runtime.last_obs.enemy.state_id or -1)
        ), 1.0, 1.0, 1.0, 0.85)
        mod.ui.text(("Input eff=%s raw=%s"):format(tostring(status.effective_now or 0), tostring(status.raw_now or 0)), 1.0, 1.0, 1.0, 0.85)
    end
end)

config.on_action("clear_training_log", function()
    local path = mod.get_path("training_log.tsv")
    local f = io.open(path, "w")
    if f then
        f:close()
        mod.log("Cleared training log: " .. path)
    else
        mod.warn("Failed to clear training log: " .. path)
    end
end)

mod.interop.provide("vs_ai:runtime", "0.1.0", {
    get_last_observation = function()
        return runtime.last_obs
    end,
    get_runtime = function()
        return runtime
    end,
})
